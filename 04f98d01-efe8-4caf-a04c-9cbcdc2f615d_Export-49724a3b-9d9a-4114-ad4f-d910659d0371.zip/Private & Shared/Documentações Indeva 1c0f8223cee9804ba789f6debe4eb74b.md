# Documentações Indeva

# Sumário

### Cadastros de colaboradores

[**Como cadastro um colaborador?**](Documentac%CC%A7o%CC%83es%20Indeva%201c0f8223cee9804ba789f6debe4eb74b/Como%20cadastro%20um%20colaborador%201c0f8223cee980adb026c0746c19f6da.md)

[**Como desligo um colaborador?**](Documentac%CC%A7o%CC%83es%20Indeva%201c0f8223cee9804ba789f6debe4eb74b/Como%20desligo%20um%20colaborador%201c0f8223cee980dcaa14d979818ce685.md)

[**Não consigo cadastrar meus colaboradores**](Documentac%CC%A7o%CC%83es%20Indeva%201c0f8223cee9804ba789f6debe4eb74b/Na%CC%83o%20consigo%20cadastrar%20meus%20colaboradores%201c0f8223cee98080b6f9c22c93dcdf90.md)

[**Cadastrei o colaborador na loja errada. Como posso corrigir?**](Documentac%CC%A7o%CC%83es%20Indeva%201c0f8223cee9804ba789f6debe4eb74b/Cadastrei%20o%20colaborador%20na%20loja%20errada%20Como%20posso%20%201c0f8223cee980f1ba35c4876794bf44.md)

[**Alterar acesso de Supervisor/Administrador/Franqueado**](Documentac%CC%A7o%CC%83es%20Indeva%201c0f8223cee9804ba789f6debe4eb74b/Alterar%20acesso%20de%20Supervisor%20Administrador%20Franque%201c0f8223cee98000afc3f6783205bae9.md)

[**Cadastrar um novo usuário (franqueado, supervisor e equivalentes)**](Documentac%CC%A7o%CC%83es%20Indeva%201c0f8223cee9804ba789f6debe4eb74b/Cadastrar%20um%20novo%20usua%CC%81rio%20(franqueado,%20supervisor%201c0f8223cee98088b341cea602a331e4.md)

[**Inativar um usuário (supervisor/administrador/franqueado**](Documentac%CC%A7o%CC%83es%20Indeva%201c0f8223cee9804ba789f6debe4eb74b/Inativar%20um%20usua%CC%81rio%20(supervisor%20administrador%20fra%201c0f8223cee980b09712de02dc8672c9.md)

[**Como cadastro o mesmo funcionário em duas lojas ao mesmo tempo?**](Documentac%CC%A7o%CC%83es%20Indeva%201c0f8223cee9804ba789f6debe4eb74b/Como%20cadastro%20o%20mesmo%20funciona%CC%81rio%20em%20duas%20lojas%20a%201c0f8223cee9801b8f48d8140fe1e5bf.md)

[**Transferir vendedor de loja**](Documentac%CC%A7o%CC%83es%20Indeva%201c0f8223cee9804ba789f6debe4eb74b/Transferir%20vendedor%20de%20loja%201c0f8223cee980b68dbfe86cf174c7b4.md)

[**Vendedor Fixo e Vendedor Temporário, quais são as diferenças?**](Documentac%CC%A7o%CC%83es%20Indeva%201c0f8223cee9804ba789f6debe4eb74b/Vendedor%20Fixo%20e%20Vendedor%20Tempora%CC%81rio,%20quais%20sa%CC%83o%20a%201c0f8223cee98006b2dac88ec80c7cc0.md)

[**Qual a diferença entre Vendedor Responsável e Gerente?**](Documentac%CC%A7o%CC%83es%20Indeva%201c0f8223cee9804ba789f6debe4eb74b/Qual%20a%20diferenc%CC%A7a%20entre%20Vendedor%20Responsa%CC%81vel%20e%20Ge%201c0f8223cee98094b7a7c14fa7056903.md)

### Atualização de vendas com PDV/ERP

[**[Microvix - usuário e senha] Por que minhas vendas pararam de subir para a Indeva?**](Documentac%CC%A7o%CC%83es%20Indeva%201c0f8223cee9804ba789f6debe4eb74b/%5BMicrovix%20-%20usua%CC%81rio%20e%20senha%5D%20Por%20que%20minhas%20venda%201c0f8223cee980f4a3a3db4c027ec58f.md)

[**[Outros sistemas] Por que minhas vendas pararam de subir para a Indeva?**](Documentac%CC%A7o%CC%83es%20Indeva%201c0f8223cee9804ba789f6debe4eb74b/%5BOutros%20sistemas%5D%20Por%20que%20minhas%20vendas%20pararam%20de%201c0f8223cee98061b399c81e70c76f1c.md)

[**O que fazer se meu sistema não possui integração automática com a Indeva?**](Documentac%CC%A7o%CC%83es%20Indeva%201c0f8223cee9804ba789f6debe4eb74b/O%20que%20fazer%20se%20meu%20sistema%20na%CC%83o%20possui%20integrac%CC%A7a%CC%83%201c1f8223cee980b9a548c8702a31e449.md)

[**Por que as vendas de um vendedor não aparecem?**](Documentac%CC%A7o%CC%83es%20Indeva%201c0f8223cee9804ba789f6debe4eb74b/Por%20que%20as%20vendas%20de%20um%20vendedor%20na%CC%83o%20aparecem%201c1f8223cee980158673dd04ff09667c.md)

[**Como abrir o integrador Indeva?**](Documentac%CC%A7o%CC%83es%20Indeva%201c0f8223cee9804ba789f6debe4eb74b/Como%20abrir%20o%20integrador%20Indeva%201c1f8223cee980478180cc42a4768091.md)

[**Vendas em Tempo Real**](Documentac%CC%A7o%CC%83es%20Indeva%201c0f8223cee9804ba789f6debe4eb74b/Vendas%20em%20Tempo%20Real%201c1f8223cee9801bb93dc5c21825cf6e.md)

[**[Erro] Conexão recusada no IP e/ou porta**](Documentac%CC%A7o%CC%83es%20Indeva%201c0f8223cee9804ba789f6debe4eb74b/%5BErro%5D%20Conexa%CC%83o%20recusada%20no%20IP%20e%20ou%20porta%201c1f8223cee9807cb4dfc956973d4cc4.md)

### Metas

[**Como cadastro uma folga para um vendedor?**](Documentac%CC%A7o%CC%83es%20Indeva%201c0f8223cee9804ba789f6debe4eb74b/Como%20cadastro%20uma%20folga%20para%20um%20vendedor%201c1f8223cee980d5baddca53061179a7.md)

[**Desliguei um vendedor, mas ele continua aparecendo na meta. O que eu faço?**](Documentac%CC%A7o%CC%83es%20Indeva%201c0f8223cee9804ba789f6debe4eb74b/Desliguei%20um%20vendedor,%20mas%20ele%20continua%20aparecendo%201c1f8223cee980d4b72ff55ea7c60d15.md)

[**Minha meta está com conflito de data. Como posso resolver?**](Documentac%CC%A7o%CC%83es%20Indeva%201c0f8223cee9804ba789f6debe4eb74b/Minha%20meta%20esta%CC%81%20com%20conflito%20de%20data%20Como%20posso%20r%201c1f8223cee980b9a78ceef29c940f91.md)

[**Como altero o formato de distribuição da meta (período ou mês)?**](Documentac%CC%A7o%CC%83es%20Indeva%201c0f8223cee9804ba789f6debe4eb74b/Como%20altero%20o%20formato%20de%20distribuic%CC%A7a%CC%83o%20da%20meta%20(p%201c1f8223cee980dca884c346c48eb7c8.md)

[**Como altero o formato de distribuição da meta (período ou mês)?**](Documentac%CC%A7o%CC%83es%20Indeva%201c0f8223cee9804ba789f6debe4eb74b/Como%20altero%20o%20formato%20de%20distribuic%CC%A7a%CC%83o%20da%20meta%20(p%201c1f8223cee980afb865c490df57fb9e.md)

### Loja

[**Por que minha loja não aparece no Web Indeva?**](Documentac%CC%A7o%CC%83es%20Indeva%201c0f8223cee9804ba789f6debe4eb74b/Por%20que%20minha%20loja%20na%CC%83o%20aparece%20no%20Web%20Indeva%201c1f8223cee98048a100e35269a0c66a.md)

### Tablet e Lista da Vez

[**Por que meu aplicativo de Lista da Vez não abre no tablet?**](Documentac%CC%A7o%CC%83es%20Indeva%201c0f8223cee9804ba789f6debe4eb74b/Por%20que%20meu%20aplicativo%20de%20Lista%20da%20Vez%20na%CC%83o%20abre%20n%201c1f8223cee980b0a6adddb27e9d5a5b.md)

[**Por que minhas marcações na Lista da Vez não estão subindo para a Indeva?**](Documentac%CC%A7o%CC%83es%20Indeva%201c0f8223cee9804ba789f6debe4eb74b/Por%20que%20minhas%20marcac%CC%A7o%CC%83es%20na%20Lista%20da%20Vez%20na%CC%83o%20es%201c1f8223cee980c48d27d4e4ede82a47.md)

[**Por que o vendedor não aparece na Lista da Vez?**](Documentac%CC%A7o%CC%83es%20Indeva%201c0f8223cee9804ba789f6debe4eb74b/Por%20que%20o%20vendedor%20na%CC%83o%20aparece%20na%20Lista%20da%20Vez%201c1f8223cee980ff9471cf9cac44fe54.md)

[**Por que o vendedor continua aparecendo na Lista da Vez?**](Documentac%CC%A7o%CC%83es%20Indeva%201c0f8223cee9804ba789f6debe4eb74b/Por%20que%20o%20vendedor%20continua%20aparecendo%20na%20Lista%20da%201c1f8223cee98094938df41aa1e7794a.md)

[**Como posso encomendar um novo totem?**](Documentac%CC%A7o%CC%83es%20Indeva%201c0f8223cee9804ba789f6debe4eb74b/Como%20posso%20encomendar%20um%20novo%20totem%201c1f8223cee980cea10cce44b3abf41b.md)

[**Quais modelos de tablet posso usar?**](Documentac%CC%A7o%CC%83es%20Indeva%201c0f8223cee9804ba789f6debe4eb74b/Quais%20modelos%20de%20tablet%20posso%20usar%201c1f8223cee9800a9ebbd787f174807b.md)

[**Alterar motivos de perdas**](Documentac%CC%A7o%CC%83es%20Indeva%201c0f8223cee9804ba789f6debe4eb74b/Alterar%20motivos%20de%20perdas%201c1f8223cee98022b80cd365088c1be6.md)

[**App Lista da Vez - Mensagem de Data e Hora Incorreta**](Documentac%CC%A7o%CC%83es%20Indeva%201c0f8223cee9804ba789f6debe4eb74b/App%20Lista%20da%20Vez%20-%20Mensagem%20de%20Data%20e%20Hora%20Incorre%201c1f8223cee9805dbf98f72809703eb4.md)

[**[VTEX Sales App] Erro: Usuário Bloqueado**](Documentac%CC%A7o%CC%83es%20Indeva%201c0f8223cee9804ba789f6debe4eb74b/%5BVTEX%20Sales%20App%5D%20Erro%20Usua%CC%81rio%20Bloqueado%201c1f8223cee980179b6ffeba672c1812.md)

[Erro "Request was denied for security"](Documentac%CC%A7o%CC%83es%20Indeva%201c0f8223cee9804ba789f6debe4eb74b/Erro%20Request%20was%20denied%20for%20security%201c1f8223cee980f7a8afd3b4004740db.md)

[**Alterar Marcações na Lista da vez**](Documentac%CC%A7o%CC%83es%20Indeva%201c0f8223cee9804ba789f6debe4eb74b/Alterar%20Marcac%CC%A7o%CC%83es%20na%20Lista%20da%20vez%201c1f8223cee9803e8ffdeed31b23de0b.md)

### Financeiro

[**Onde consigo informações sobre minhas faturas em aberto?**](Documentac%CC%A7o%CC%83es%20Indeva%201c0f8223cee9804ba789f6debe4eb74b/Onde%20consigo%20informac%CC%A7o%CC%83es%20sobre%20minhas%20faturas%20em%201c1f8223cee980ad9c2df2aeffa519e8.md)

### Suporte

[**Abrindo uma solicitação para o suporte**](Documentac%CC%A7o%CC%83es%20Indeva%201c0f8223cee9804ba789f6debe4eb74b/Abrindo%20uma%20solicitac%CC%A7a%CC%83o%20para%20o%20suporte%201c1f8223cee98081856cc39b4bc2f708.md)

[**Conversando com a Eva/ Abrindo um ticket com o Suporte Indeva**](Documentac%CC%A7o%CC%83es%20Indeva%201c0f8223cee9804ba789f6debe4eb74b/Conversando%20com%20a%20Eva%20Abrindo%20um%20ticket%20com%20o%20Supo%201c1f8223cee980a8b1b2f68a7c26371d.md)

### Conta do usuário

[**Dados da conta do Usuário**](Documentac%CC%A7o%CC%83es%20Indeva%201c0f8223cee9804ba789f6debe4eb74b/Dados%20da%20conta%20do%20Usua%CC%81rio%201c1f8223cee9806298b7f7bc84045587.md)

[**Cadastrar senha/Redefinir senha para o acesso à Indeva!**](Documentac%CC%A7o%CC%83es%20Indeva%201c0f8223cee9804ba789f6debe4eb74b/Cadastrar%20senha%20Redefinir%20senha%20para%20o%20acesso%20a%CC%80%20I%201c0f8223cee980498454ef18a27258fa.md)

[**➕ Adicionar uma nova loja**](Documentac%CC%A7o%CC%83es%20Indeva%201c0f8223cee9804ba789f6debe4eb74b/%E2%9E%95%20Adicionar%20uma%20nova%20loja%201c1f8223cee9804e80ddccd0fb3e5c60.md)

[**Termo de Uso**](Documentac%CC%A7o%CC%83es%20Indeva%201c0f8223cee9804ba789f6debe4eb74b/Termo%20de%20Uso%201c1f8223cee980b6ad29d1e2ff3c7b8d.md)

[**Acessando a Área Financeira**](Documentac%CC%A7o%CC%83es%20Indeva%201c0f8223cee9804ba789f6debe4eb74b/Acessando%20a%20A%CC%81rea%20Financeira%201c1f8223cee980958be3ccad0997dd43.md)

[**Navegando na Área Financeira**](Documentac%CC%A7o%CC%83es%20Indeva%201c0f8223cee9804ba789f6debe4eb74b/Navegando%20na%20A%CC%81rea%20Financeira%201c1f8223cee9805fb6aac84d0347e79f.md)

[**Processo de cancelamento**](Documentac%CC%A7o%CC%83es%20Indeva%201c0f8223cee9804ba789f6debe4eb74b/Processo%20de%20cancelamento%201c1f8223cee98075a5d0f3d140e9e6b0.md)

[**Painel de solicitações**](Documentac%CC%A7o%CC%83es%20Indeva%201c0f8223cee9804ba789f6debe4eb74b/Painel%20de%20solicitac%CC%A7o%CC%83es%201c1f8223cee980e0b1b3fc8b6b402103.md)

### Visão Geral

[**Por que o vendedor cadastrado ainda não apareceu na visão geral?**](Documentac%CC%A7o%CC%83es%20Indeva%201c0f8223cee9804ba789f6debe4eb74b/Por%20que%20o%20vendedor%20cadastrado%20ainda%20na%CC%83o%20apareceu%20%201c1f8223cee9807e9fe6de698ba2fdfc.md)

[**Por que o vendedor desligado ainda aparece na visão geral?**](Documentac%CC%A7o%CC%83es%20Indeva%201c0f8223cee9804ba789f6debe4eb74b/Por%20que%20o%20vendedor%20desligado%20ainda%20aparece%20na%20visa%201c1f8223cee980b0822cf4a76ab796df.md)

[**Visão Geral**](Documentac%CC%A7o%CC%83es%20Indeva%201c0f8223cee9804ba789f6debe4eb74b/Visa%CC%83o%20Geral%201c1f8223cee980e787ebcf1993f8ee7a.md)

### Vendedores

[**Painel de vendedor**](Documentac%CC%A7o%CC%83es%20Indeva%201c0f8223cee9804ba789f6debe4eb74b/Painel%20de%20vendedor%201c0f8223cee980a98860e280719d4631.md)

[**Cadastro de vendedor**](Documentac%CC%A7o%CC%83es%20Indeva%201c0f8223cee9804ba789f6debe4eb74b/Cadastro%20de%20vendedor%201c0f8223cee9804f821dc1fff55b500a.md)

[Vendedor Temporário](Documentac%CC%A7o%CC%83es%20Indeva%201c0f8223cee9804ba789f6debe4eb74b/Vendedor%20Tempora%CC%81rio%201c0f8223cee98026a85edddb81cd915f.md)

[**Vendedor de Férias**](Documentac%CC%A7o%CC%83es%20Indeva%201c0f8223cee9804ba789f6debe4eb74b/Vendedor%20de%20Fe%CC%81rias%201c2f8223cee9800a82dac655de605f6b.md)

[**Desligar vendedor**](Documentac%CC%A7o%CC%83es%20Indeva%201c0f8223cee9804ba789f6debe4eb74b/Desligar%20vendedor%201c2f8223cee980579dc0c619916c5500.md)

[**Vendedor responsável (VR)**](Documentac%CC%A7o%CC%83es%20Indeva%201c0f8223cee9804ba789f6debe4eb74b/Vendedor%20responsa%CC%81vel%20(VR)%201c0f8223cee980669be6d25e5900e443.md)

[**Desligando o Vendedor Responsável**](Documentac%CC%A7o%CC%83es%20Indeva%201c0f8223cee9804ba789f6debe4eb74b/Desligando%20o%20Vendedor%20Responsa%CC%81vel%201c2f8223cee9809b9088d1f8d073695c.md)

[**Status de Vendedor**](Documentac%CC%A7o%CC%83es%20Indeva%201c0f8223cee9804ba789f6debe4eb74b/Status%20de%20Vendedor%201c2f8223cee9802ba92ecd3f820894be.md)

### Gerentes

[**Cadastro de gerente**](Documentac%CC%A7o%CC%83es%20Indeva%201c0f8223cee9804ba789f6debe4eb74b/Cadastro%20de%20gerente%201c0f8223cee9804792bad520d9592384.md)

[**Desligar gerente**](Documentac%CC%A7o%CC%83es%20Indeva%201c0f8223cee9804ba789f6debe4eb74b/Desligar%20gerente%201c0f8223cee98008aa43eae75e0f88e9.md)

[**Gerente de Férias**](Documentac%CC%A7o%CC%83es%20Indeva%201c0f8223cee9804ba789f6debe4eb74b/Gerente%20de%20Fe%CC%81rias%201c1f8223cee98059b86ac5b1b063a472.md)

[**Visualizando Feedback**](Documentac%CC%A7o%CC%83es%20Indeva%201c0f8223cee9804ba789f6debe4eb74b/Visualizando%20Feedback%201c2f8223cee980b8b6ecc16563c83fa4.md)

### Cadastro de Metas

[**Vamos começar?**](Documentac%CC%A7o%CC%83es%20Indeva%201c0f8223cee9804ba789f6debe4eb74b/Vamos%20comec%CC%A7ar%201c2f8223cee98092b534dd888404f1b6.md)

[**PASSO 1 - Escolha uma loja**](Documentac%CC%A7o%CC%83es%20Indeva%201c0f8223cee9804ba789f6debe4eb74b/PASSO%201%20-%20Escolha%20uma%20loja%201c2f8223cee980508531ebd17d040874.md)

[**PASSO 2 - Controle do ciclo de meta**](Documentac%CC%A7o%CC%83es%20Indeva%201c0f8223cee9804ba789f6debe4eb74b/PASSO%202%20-%20Controle%20do%20ciclo%20de%20meta%201c1f8223cee9805891c8e432c572e6d0.md)

[**PASSO 3 - Definição do ciclo temporal da meta**](Documentac%CC%A7o%CC%83es%20Indeva%201c0f8223cee9804ba789f6debe4eb74b/PASSO%203%20-%20Definic%CC%A7a%CC%83o%20do%20ciclo%20temporal%20da%20meta%201c2f8223cee980359cfde3808dbc31f8.md)

[**PASSO 4 - Divisão do ciclo da meta em períodos**](Documentac%CC%A7o%CC%83es%20Indeva%201c0f8223cee9804ba789f6debe4eb74b/PASSO%204%20-%20Divisa%CC%83o%20do%20ciclo%20da%20meta%20em%20peri%CC%81odos%201c2f8223cee980cf9d75d38a6996680a.md)

[**PASSO 5 - Valores dos períodos da meta**](Documentac%CC%A7o%CC%83es%20Indeva%201c0f8223cee9804ba789f6debe4eb74b/PASSO%205%20-%20Valores%20dos%20peri%CC%81odos%20da%20meta%201c2f8223cee98027af2efd16107d2d20.md)

[**PASSO 6 - Folgas e feriados**](Documentac%CC%A7o%CC%83es%20Indeva%201c0f8223cee9804ba789f6debe4eb74b/PASSO%206%20-%20Folgas%20e%20feriados%201c1f8223cee980a1b477fd3fb81ac769.md)

[**PASSO 7 - Distribuição de pesos**](Documentac%CC%A7o%CC%83es%20Indeva%201c0f8223cee9804ba789f6debe4eb74b/PASSO%207%20-%20Distribuic%CC%A7a%CC%83o%20de%20pesos%201c2f8223cee98097b765f12a8b451b89.md)

[**PASSO 8 - Formato de metas dos vendedores**](Documentac%CC%A7o%CC%83es%20Indeva%201c0f8223cee9804ba789f6debe4eb74b/PASSO%208%20-%20Formato%20de%20metas%20dos%20vendedores%201c2f8223cee9803ea099fd19b1ac59ca.md)

[**PASSO 9 - Revisão**](Documentac%CC%A7o%CC%83es%20Indeva%201c0f8223cee9804ba789f6debe4eb74b/PASSO%209%20-%20Revisa%CC%83o%201c2f8223cee9803db27ce4af5f5ae2d8.md)

### Validação

[**Validação manual**](Documentac%CC%A7o%CC%83es%20Indeva%201c0f8223cee9804ba789f6debe4eb74b/Validac%CC%A7a%CC%83o%20manual%201c0f8223cee9805aa4adee5d05ba5945.md)

[Status Validação](Documentac%CC%A7o%CC%83es%20Indeva%201c0f8223cee9804ba789f6debe4eb74b/Status%20Validac%CC%A7a%CC%83o%201c1f8223cee9805bbb88d6f379992be2.md)

### Feedback

[**Visualizar feedback no app Indeva - Lista da vez**](Documentac%CC%A7o%CC%83es%20Indeva%201c0f8223cee9804ba789f6debe4eb74b/Visualizar%20feedback%20no%20app%20Indeva%20-%20Lista%20da%20vez%201c1f8223cee9807da9b2d03565afcd64.md)

[**Registrar o feedback para vendedores**](Documentac%CC%A7o%CC%83es%20Indeva%201c0f8223cee9804ba789f6debe4eb74b/Registrar%20o%20feedback%20para%20vendedores%201c1f8223cee98077afbef196b95a490c.md)

[**Não consigo cadastrar o feedback dos vendedores**](Documentac%CC%A7o%CC%83es%20Indeva%201c0f8223cee9804ba789f6debe4eb74b/Na%CC%83o%20consigo%20cadastrar%20o%20feedback%20dos%20vendedores%201c1f8223cee980afaf41d1d718ba245a.md)

[**Cadastrar feedback para Gerente**](Documentac%CC%A7o%CC%83es%20Indeva%201c0f8223cee9804ba789f6debe4eb74b/Cadastrar%20feedback%20para%20Gerente%201c2f8223cee980b0ae66ec5547f95c1b.md)

### Ranking

[**Tudo sobre Rankings!**](Documentac%CC%A7o%CC%83es%20Indeva%201c0f8223cee9804ba789f6debe4eb74b/Tudo%20sobre%20Rankings!%201c2f8223cee980aca6e6c745919a1f60.md)

[**Tudo sobre Campanhas!**](Documentac%CC%A7o%CC%83es%20Indeva%201c0f8223cee9804ba789f6debe4eb74b/Tudo%20sobre%20Campanhas!%201c2f8223cee9809d8af0f88b0a2e204a.md)

### Relatórios

[**Filtrar dados**](Documentac%CC%A7o%CC%83es%20Indeva%201c0f8223cee9804ba789f6debe4eb74b/Filtrar%20dados%201c2f8223cee98058ae1bd695e21e3c30.md)

[**Raio X**](Documentac%CC%A7o%CC%83es%20Indeva%201c0f8223cee9804ba789f6debe4eb74b/Raio%20X%201c2f8223cee9803499e2ced23196047b.md)

[**Evolução (Relatório)**](Documentac%CC%A7o%CC%83es%20Indeva%201c0f8223cee9804ba789f6debe4eb74b/Evoluc%CC%A7a%CC%83o%20(Relato%CC%81rio)%201c2f8223cee98054ac34f8641b23d8e5.md)

[**Motivos de perdas (Relatório)**](Documentac%CC%A7o%CC%83es%20Indeva%201c0f8223cee9804ba789f6debe4eb74b/Motivos%20de%20perdas%20(Relato%CC%81rio)%201c2f8223cee9805496cac8e16d134189.md)

[**Fluxo de Oportunidades**](Documentac%CC%A7o%CC%83es%20Indeva%201c0f8223cee9804ba789f6debe4eb74b/Fluxo%20de%20Oportunidades%201c2f8223cee980369f89d7be58b152cb.md)

[**Fluxo de Aproveitamento**](Documentac%CC%A7o%CC%83es%20Indeva%201c0f8223cee9804ba789f6debe4eb74b/Fluxo%20de%20Aproveitamento%201c2f8223cee980e29d5be09ac756fb82.md)

[**Mural de Vendas**](Documentac%CC%A7o%CC%83es%20Indeva%201c0f8223cee9804ba789f6debe4eb74b/Mural%20de%20Vendas%201c2f8223cee980c68b3affd354477d34.md)

[**Comparador de períodos**](Documentac%CC%A7o%CC%83es%20Indeva%201c0f8223cee9804ba789f6debe4eb74b/Comparador%20de%20peri%CC%81odos%201c2f8223cee9806cac4ff4a69c0e7f4c.md)

[**Lista da Vez (Relatório)**](Documentac%CC%A7o%CC%83es%20Indeva%201c0f8223cee9804ba789f6debe4eb74b/Lista%20da%20Vez%20(Relato%CC%81rio)%201c2f8223cee9802b8468d352a2186974.md)

[**Feedbacks (Relatório)**](Documentac%CC%A7o%CC%83es%20Indeva%201c0f8223cee9804ba789f6debe4eb74b/Feedbacks%20(Relato%CC%81rio)%201c2f8223cee9805ba68de58b0acf3591.md)

[**Fluxo de Oportunidades (Relatório)**](Documentac%CC%A7o%CC%83es%20Indeva%201c0f8223cee9804ba789f6debe4eb74b/Fluxo%20de%20Oportunidades%20(Relato%CC%81rio)%201c2f8223cee980228d48e5d5515e9fb8.md)

[**Eventos e Motivos**](Documentac%CC%A7o%CC%83es%20Indeva%201c0f8223cee9804ba789f6debe4eb74b/Eventos%20e%20Motivos%201c2f8223cee980f0b6e1c66cb77d5a2c.md)

### Formulários

[**O que são os Formulários da Indeva?**](Documentac%CC%A7o%CC%83es%20Indeva%201c0f8223cee9804ba789f6debe4eb74b/O%20que%20sa%CC%83o%20os%20Formula%CC%81rios%20da%20Indeva%201c4f8223cee9804990e8d03aaf4a5c01.md)

[**Passo 1: Criando o Formulário**](Documentac%CC%A7o%CC%83es%20Indeva%201c0f8223cee9804ba789f6debe4eb74b/Passo%201%20Criando%20o%20Formula%CC%81rio%201c4f8223cee980e98fb8ca9b0fdd3863.md)

[**Passo 2 - Conferindo as respostas**](Documentac%CC%A7o%CC%83es%20Indeva%201c0f8223cee9804ba789f6debe4eb74b/Passo%202%20-%20Conferindo%20as%20respostas%201c4f8223cee980e1b155ecec673d6c61.md)

[**Respondendo o Formulário - Para Gerente/VR**](Documentac%CC%A7o%CC%83es%20Indeva%201c0f8223cee9804ba789f6debe4eb74b/Respondendo%20o%20Formula%CC%81rio%20-%20Para%20Gerente%20VR%201c4f8223cee9805199a6e39b8eaa74a5.md)

### Lista da Vez

[**Usabilidade**](Documentac%CC%A7o%CC%83es%20Indeva%201c0f8223cee9804ba789f6debe4eb74b/Usabilidade%201c4f8223cee980408a04cf65b49c2f1d.md)

[**Status das cores na fila da Lista da Vez**](Documentac%CC%A7o%CC%83es%20Indeva%201c0f8223cee9804ba789f6debe4eb74b/Status%20das%20cores%20na%20fila%20da%20Lista%20da%20Vez%201c4f8223cee980e286aecf095f5cc13c.md)

[**Aplicativos Indeva**](Documentac%CC%A7o%CC%83es%20Indeva%201c0f8223cee9804ba789f6debe4eb74b/Aplicativos%20Indeva%201c1f8223cee980c28531c1649e19d398.md)

### Ajuda

[**Ajuda**](Documentac%CC%A7o%CC%83es%20Indeva%201c0f8223cee9804ba789f6debe4eb74b/Ajuda%201c4f8223cee9807fa211e6f3f1bee962.md)

### Usabilidade

[**Entendendo a Usabilidade**](Documentac%CC%A7o%CC%83es%20Indeva%201c0f8223cee9804ba789f6debe4eb74b/Entendendo%20a%20Usabilidade%201c4f8223cee98049ad37e1b08e8c988b.md)

### Treinamento Indeva

[**Iniciando na Indeva**](Documentac%CC%A7o%CC%83es%20Indeva%201c0f8223cee9804ba789f6debe4eb74b/Iniciando%20na%20Indeva%201c4f8223cee980529782ccc60ee8f5f0.md)

### Webinar - Confira o conteúdo realizado em nossas transmissões

[**Entendendo a Usabilidade na Indeva**](Documentac%CC%A7o%CC%83es%20Indeva%201c0f8223cee9804ba789f6debe4eb74b/Entendendo%20a%20Usabilidade%20na%20Indeva%201c4f8223cee98089865cd88f0b8053c5.md)

[**Campanhas e Rankings na Indeva**](Documentac%CC%A7o%CC%83es%20Indeva%201c0f8223cee9804ba789f6debe4eb74b/Campanhas%20e%20Rankings%20na%20Indeva%201c4f8223cee980a6a81fdf55d5c3d624.md)

[**Aplicando o Feedback na Indeva**](Documentac%CC%A7o%CC%83es%20Indeva%201c0f8223cee9804ba789f6debe4eb74b/Aplicando%20o%20Feedback%20na%20Indeva%201c4f8223cee98007a713fc5d8c98d34f.md)

[**Entendendo a Visão Geral Indeva**](Documentac%CC%A7o%CC%83es%20Indeva%201c0f8223cee9804ba789f6debe4eb74b/Entendendo%20a%20Visa%CC%83o%20Geral%20Indeva%201c4f8223cee980938d66d4fd05ae03c2.md)

[**O que fazer quando o time não bate metas**](Documentac%CC%A7o%CC%83es%20Indeva%201c0f8223cee9804ba789f6debe4eb74b/O%20que%20fazer%20quando%20o%20time%20na%CC%83o%20bate%20metas%201c4f8223cee980928f95f8cdfa467c9f.md)

[**Relatório Lista da Vez**](Documentac%CC%A7o%CC%83es%20Indeva%201c0f8223cee9804ba789f6debe4eb74b/Relato%CC%81rio%20Lista%20da%20Vez%201c4f8223cee980659c77e810a0ac0cb6.md)

### Aparelhos/acessórios

[**Equipamento & Totem**](Documentac%CC%A7o%CC%83es%20Indeva%201c0f8223cee9804ba789f6debe4eb74b/Equipamento%20&%20Totem%201c1f8223cee9800b9f5ff45cf2cdaf26.md)