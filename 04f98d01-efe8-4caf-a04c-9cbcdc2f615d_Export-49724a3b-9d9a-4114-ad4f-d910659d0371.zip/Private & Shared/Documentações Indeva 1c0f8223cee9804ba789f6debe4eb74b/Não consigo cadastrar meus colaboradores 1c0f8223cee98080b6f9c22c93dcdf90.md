# Não consigo cadastrar meus colaboradores

Existem algumas situações que podem causar erros na hora de cadastrar vendedores ou gerentes. Seguem exemplos de erros comuns:

**Erro #1: “Colaborador tem um período de data em conflito com a data escolhida em outra loja”**

Se o seu colaborador já utilizou a Indeva e foi desligado do sistema depois (até mesmo por cancelamento da Indeva da loja), **a “data de início” escolhida tem de ser depois da data de desligamento dele na Indeva**, pois se encerrou para ele um período no sistema. No caso desse erro, tente datas mais próximas, e caso o erro persista, acione o time de suporte no chat.

**Erro #2: “CPF já está ativo na loja (nome da loja)”**

Talvez a última loja em que seu colaborador utilizou a Indeva não o tenha desligado corretamente. Neste caso, verificar o período cadastrado no histórico do vendedor.

**Erro #3: “CPF é inválido”**

Nossa plataforma é programada para só aceitar o cadastro de CPFs válidos, de acordo com a legislação brasileira. Caso apareça esse erro, confira se não houve erro de digitação, e se for o caso, verifique novamente o número de CPF com o colaborador.

> 🔎Importante: Caso você esteja tentando transferir um vendedor entre lojas, siga este tutorial: [Transferir vendedor de loja](https://indeva.elevio.help/pt-br/articles/167)
>