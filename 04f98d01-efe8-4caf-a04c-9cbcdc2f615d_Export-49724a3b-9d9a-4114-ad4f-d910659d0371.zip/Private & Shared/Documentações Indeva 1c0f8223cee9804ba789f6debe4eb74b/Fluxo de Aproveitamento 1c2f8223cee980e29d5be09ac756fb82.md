# Fluxo de Aproveitamento

Você sabe qual é o horário de maior aproveitamento das vendas na sua loja?

A Indeva faz um comparativo da **média de conversão** *versus* a **conversão de hora em hora**. Assim, só de bater o olho, fica fácil saber os horários onde há maior aproveitamento das vendas!

Você acessa esse relatório assim:

> Entre no Menu da Indeva (na lateral esquerda) > 📄 Relatórios > [Fluxo de oportunidades](Fluxo%20de%20Oportunidades%201c2f8223cee980369f89d7be58b152cb.md).
> 

O objetivo deste relatório é avaliar em qual momento a sua loja recebe o maior número de clientes. No gráfico de “**Fluxo de Aproveitamento”** você observa a **média da taxa de conversão** e em quais horários as vendas estão acompanhando esta média da loja (tudo de hora em hora).

👉 O ideal é que taxa de conversão esteja sempre acima da linha (laranja) que representa a média da loja!

### **Gráfico Fluxo de Aproveitamento**

![](https://cdn.elev.io/file/uploads/QBzHaXAsXxOVU9cJt8qy4K7_fCUmprAgEkSOPIaQEPs/6AlT2YngKDQ50UlJZq9qrRaG-MXC9OUg10gSOmdQxZk/Snap%202018-01-30%20at%2014.54.26-HGU.png)

😉 **Dica -** Coloque o mouse em cima dos pontos de pico no gráfico e você terá a informação do percentual da taxa de conversão. (Veja exemplo)

![](https://cdn.elev.io/file/uploads/QBzHaXAsXxOVU9cJt8qy4K7_fCUmprAgEkSOPIaQEPs/gB1qo49iGsIjoXl-bVT1pFCEByHqeYAhd5DH36tE-Ao/Snap%202018-01-30%20at%2016.33.50-GoQ.png)

⚠️ **Atenção -** É preciso filtrar a data início e fim antes de acessar as informações de qualquer relatório. =)