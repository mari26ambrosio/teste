# Evolução (Relatório)

A **Evolução diária** é um relatório completo que facilita a vida de quem gerencia uma loja! Você acessa ele assim:

> Entre no Menu da Indeva (na lateral esquerda) > 📄 Relatórios > Evolução diária.
> 

Chega de calculadora e de cálculos complicados! Agora em uma única tela você acompanha toda a evolução diária da loja através dos indicadores, valores de metas e valores vendidos.

O interessante deste relatório é que você consegue comparar a **Meta Acumulada** com a **Venda Acumulada** e ainda saber o valor da diferença entre eles na coluna **“Saldo Vendas”.** Nesta coluna aparecem os valores devedores (na cor vermelha) e valores acima do planejado (na cor azul).

**Projeção de vendas**

Você também vai conseguir explorar e ter uma visão da sua venda projetada. Basta clicar em **Filtrar dados** e selecionar o período futuro que deseja realizar a consulta.

A projeção facilita sua visão de como poderá ser o fechamento das suas vendas até o fim da meta ou até a data que selecionar.

**Esta projeção é calculada com base no atingimento da meta no período atual e do ano passado.**

Todas estas informações podem ser exportadas para excel, é só clicar no botão (verde) **Exportar Excel.**

⚠️ **Atenção -** É preciso filtrar a data início e fim antes de acessar as informações de qualquer relatório. =)