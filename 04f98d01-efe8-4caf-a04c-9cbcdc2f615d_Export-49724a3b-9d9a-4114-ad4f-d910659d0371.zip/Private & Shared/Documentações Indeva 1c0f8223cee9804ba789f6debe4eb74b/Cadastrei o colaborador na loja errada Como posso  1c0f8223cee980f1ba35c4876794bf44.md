# Cadastrei o colaborador na loja errada. Como posso corrigir?

Será necessário inativar o cadastro que foi feito na loja errada e, somente depois disso, cadastrar o colaborador na loja certa.

> ⚠️Importante: o colaborador só poderá ser cadastrado na nova loja com uma data de início posterior à data de encerramento na outra loja, combinado? Exemplo: se a data de desligamento na loja A foi 01/01/2022, o colaborador só poderá ser cadastrado na loja B com data de início a partir de 02/01/2022.
> 

O caminho para corrigir essa informação depende se o colaborador é gerente ou se é vendedor.

**1) Se o colaborador for um vendedor:**

Para inativar um cadastro: entre em Cadastros > Vendedores > Ações > Férias ou Inativar > Desligamento.

Para realizar um novo cadastro: entre em Cadastros > Vendedores > Cadastrar Vendedor.

Selecione se o vendedor será Fixo ou Temporário, preencha as informações corretamente e depois é só salvar!

**2) Se o colaborador for um gerente:**

Para inativar um cadastro: entre em Cadastros > Gerentes > Ações > Férias ou Inativar > Desligamento.

Para realizar um novo cadastro: entre em Cadastros > Gerentes > Cadastrar Gerente.