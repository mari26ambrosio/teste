# Motivos de perdas (Relatório)

O objetivo deste relatório é informar os **motivos de perda de vendas**, a quantidade de vendas perdidas para cada um desses motivos e o quanto isso reflete em percentual.

Você acessa esse relatório assim:

> Entre no Menu da Indeva (na lateral esquerda) > 📄 Relatórios > Motivos de perdas.
> 

![](https://cdn.elev.io/file/uploads/QBzHaXAsXxOVU9cJt8qy4K7_fCUmprAgEkSOPIaQEPs/uZ7FODNC6aFPDirCSOHGmDXk5mjRobT6aHN2mHuSWHI/Snap%202018-01-30%20at%2009.43.47--5o.png)

Esta tela traz informações quentinhas da lista da vez digital com todos os motivos de não conversão que os vendedores registraram lá.

### **Informações personalizadas**

👉 Para escolher vendedor, período e qual “**item do motivo de não conversão**” é só selecionar pelo filtro da lateral esquerda.

**Ver cada detalhe da perda da venda te ajuda a criar um plano de ação para reposição de estoque, por exemplo.**

O mesmo ocorre quando há recorrência de perda de venda, onde é possível analisar e definir estratégias de abordagem no atendimento ao cliente.

⚠️ **Atenção -** É preciso filtrar a data início e fim antes de acessar as informações de qualquer relatório. =)