# Vendedor Fixo e Vendedor Temporário, quais são as diferenças?

Todos eles ficam disponíveis no app Lista da Vez, participam da meta, podem receber feedbacks e também fazem parte de campanhas/rankings.

A **única diferença** é que ao cadastrar o Vendedor Temporário é, obrigatoriamente, preciso informar a **data fim**.