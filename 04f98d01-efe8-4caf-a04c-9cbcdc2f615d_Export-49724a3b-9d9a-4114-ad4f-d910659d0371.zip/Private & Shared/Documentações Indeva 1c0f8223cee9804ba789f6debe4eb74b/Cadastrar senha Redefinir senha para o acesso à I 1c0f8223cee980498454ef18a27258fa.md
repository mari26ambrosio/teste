# Cadastrar senha/Redefinir senha para o acesso à Indeva!

![](https://cdn.elev.io/file/uploads/QBzHaXAsXxOVU9cJt8qy4K7_fCUmprAgEkSOPIaQEPs/xdgkhwLIc-R_nBZ_Gsyt7cFTr-Mq7w_i89gz6XrUXd0/question-6XA.png)

Para cadastrar uma senha acesso ao site, **digite seu e-mail** na tela de login do sistema (web.indeva.com.br) e **clique em continuar**.

![](https://cdn.elev.io/file/uploads/-ePN07yhB4Livmc1Xh5I83nMD6RUKrpxaz6S3MgSFis/gjag02Pr4sTJw-RIBZ6xfxiM5WYvgkUfxpy8SO6wmyc/1660602710517-V0Q.png)

Na tela seguinte, clique em "Esqueci Minha Senha".

![](https://cdn.elev.io/file/uploads/-ePN07yhB4Livmc1Xh5I83nMD6RUKrpxaz6S3MgSFis/Ag4pYa3zFZAMZ69KOTwdAG1h7llcKz5CNhOt4bAJ1js/1660602959864-Vus.png)

**Dentro de alguns minutos o sistema enviará para o e-mail um link para cadastrar nova senha.** Caso o e-mail não chegue na sua caixa de entrada ou o sistema não identifique o e-mail que foi informado, entre em contato conosco para verificarmos, ok? 😉