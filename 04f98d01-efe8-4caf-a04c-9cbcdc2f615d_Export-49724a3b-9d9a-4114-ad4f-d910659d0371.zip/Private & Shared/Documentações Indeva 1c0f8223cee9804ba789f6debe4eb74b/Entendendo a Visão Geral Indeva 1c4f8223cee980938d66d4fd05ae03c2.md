# Entendendo a Visão Geral Indeva

🎥Nesse **Webinar** apresentamos para você como funciona a **Visão Geral** da plataforma **Indeva**.

Você conhece todos os recursos que estão na **Visão Geral da Indeva**?🤔

Como o sistema calcula a meta acumulada?🤔

Os alertas da plataforma?🤔

E os indicadores de performance da loja? 🤔

**Opa!** Se você ainda não está por dentro de como a **Indeva** pode te ajudar com essas informações, temos uma ótima notícia para você!🎉

Assista por esse link:

[**https://youtu.be/49HV8Fmpr_4**](https://youtu.be/49HV8Fmpr_4) - Parte 1

[**https://youtu.be/NKFDy6v8O2Y**](https://youtu.be/NKFDy6v8O2Y) - Parte 2