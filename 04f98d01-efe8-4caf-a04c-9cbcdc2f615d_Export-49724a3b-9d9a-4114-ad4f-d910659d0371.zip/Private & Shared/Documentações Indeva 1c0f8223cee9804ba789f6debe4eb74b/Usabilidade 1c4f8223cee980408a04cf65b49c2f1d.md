# Usabilidade

A usabilidade é a métrica criada pela Indeva que ajuda o gerente avaliar se os registros de “sucessos” na **lista da vez** estão sendo realizados de forma correta pelos vendedores.

Para acompanhar a usabilidade, entre no menu “relatórios”, “raio x”. Acreditamos que um percentual de usabilidade aceitável é de 85%, ideal 90% e excelente 95%.

> 👍 No relatório Raio X, a usabilidade (+) é quando o vendedor informa mais “sucessos” na lista da vez do que realizou no PDV.
> 
> 
> 👎 No relatório Raio X, A **usabilidade (-)** é quando o vendedor deixou de marcar “sucessos” na lista da vez.
> 

Se preferir entre em “relatórios” ,“lista da vez” , coloque o dia que deseja consultar. Nesta tela terá informações de registros na lista da vez. Assim você pode comparar os “sucessos” marcados na lista da vez com o realizado em seu PDV.

⚠️ **Atenção -** A usabilidade é uma métrica exclusiva para medir o número de sucessos marcados pelos seus vendedores na **Lista da Vez - Digital.** A usabilidade não é uma métrica que mede o quanto você usa ou deixa de usar a **Indeva** **web** ou a **Lista da Vez** corretamente, ok? Cuidado para não criar confusão. 😉