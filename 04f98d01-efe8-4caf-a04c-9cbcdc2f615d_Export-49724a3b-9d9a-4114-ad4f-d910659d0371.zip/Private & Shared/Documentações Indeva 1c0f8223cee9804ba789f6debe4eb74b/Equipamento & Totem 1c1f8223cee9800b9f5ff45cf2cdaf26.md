# Equipamento & Totem

Recomendamos a utilização de alguns modelos de tablets e da aquisição do suporte de proteção (Totem) para deixá-lo disponível no salão de vendas.

| Tipo de Totem | Modelo de tablet |
| --- | --- |
| Padronizados | - *TABLET SAMSUNG T290N -* TABLET SAMSUNG T295N - A7 Lite (tela de 8,7 polegadas)- A9 (tela de 8,7 polegadas)- A9+ (Tela de 11") |
| Não recomendado | - Modelos que tenha o **Android/Apple IOS superior a versão 11.** |

### **Luva de proteção (Recomendação)**

> Importante: Recomendamos o uso dos totens apenas aos tablets que utilizam Indeva - Lista da vez. Para o aplicativo VTEX Sales App, que só pode ser instalado em versões acima do android 11, não temos recomendações de totens.
> 

🎥Aqui você aprende como montar o totem de acrílico da **Indeva**! 🛠Você pode encontrar as luvas de proteção (totem) acessando o site de nosso parceiro: [**https://www.totemfacil.com.br/**](https://www.totemfacil.com.br/)

> Clique no link abaixo e confira!😉
> 
> 
> [**Assista o vídeo aqui!**](https://youtu.be/4hxEAR6XDJ0)
> 

> ⚠️ Para troca ou manutenção sobre o **equipamento de totem** sugerimos que encontre um técnico autorizado ou a loja de origem da aquisição.
>