# Alterar motivos de perdas

Uma das principais ferramentas de análise que a Indeva oferece são os **motivos de perdas**. Eles permitem entender as razões que levaram o cliente a não comprar na loja. Para facilitar as marcações dos vendedores no tablet e as análises dessas marcações, os motivos devem conter informações **simples** e **relevantes** para o seu negócio.

Caso queira alterar os motivos de perdas, seguem algumas informações importantes:

> 👉Todas as alterações nos motivos de não conversão são feitas por rede, por isso recomendamos levá-las a um consultor para validação antes que sejam aplicadas a toda a rede. Por esse motivo, gerentes não podem solicitar ajustes nos motivos de perda.
> 

> 👉 Os motivos de perda são cadastrados na plataforma por meio de uma planilha específica que é disponibilizada pelos nossos analistas de suporte, sendo de responsabilidade da rede a inclusão ou remoção dos motivos.
> 

> 👉O tempo de implementação das mudanças pode variar entre 15 e 30 dias a partir da abertura do chamado, dependendo da complexidade das mudanças.
> 

Seguem boas práticas na hora do preenchimento:

- O produto que for excluir, pintar a célula na cor vermelha
- O produto que for inserir, pintar a célula na cor Verde
- Não pode conter linhas vazias
- Inserir os produtos na respectiva categoria e sendo na coluna à direita da categoria pai.
- Precisamos receber o arquivo no formato de excel

![](https://cdn.elev.io/file/uploads/5G0ie0odcvxxzlQJCL8hk63Tz97zk9dh4tLJhVkC1lk/iTcJInxO9qqcjosaZzzkLuYZ60DwIuAeLZmu8uGeHzI/inline188098174-aQk.png)

Para exemplificar melhor como realizar os ajustes na planilha, fizemos um vídeo com as orientações: [**Assista o vídeo aqui**](https://www.loom.com/share/b157ebc71a434cbebebb2d84e1d11d54?sid=50529728-4dd7-4a7d-bd1b-2e014cdddd76).