# Visão Geral

Conheça o Visão Geral Indeva:

O Menu **Visão Geral** é a página inicial do **Indeva Web**. Tentamos concentrar todas as informações mais importantes nesta tela para você! De maneira rápida e simples você acompanha:

1. **Os Alertas:** todos os dias fique de olho e veja as principais pendências relacionadas ao bom funcionamento da sua loja. Esses alertas identificam o que precisa ser realizado.

![](https://cdn.elev.io/file/uploads/-ePN07yhB4Livmc1Xh5I83nMD6RUKrpxaz6S3MgSFis/sR2_5qKCfLxhkTISywhFlbq0616aDcFyCwlrICEVeS4/1660952526705-7Og.png)

1. **Vendas:** acompanhe os números acumulados das suas vendas e saiba se a loja está na meta ou não.
    
    ![](https://cdn.elev.io/file/uploads/-ePN07yhB4Livmc1Xh5I83nMD6RUKrpxaz6S3MgSFis/aqQ3rzeWZwzlzWdeLmQqOpWloPEKAc7KCcF-KGmdvRQ/1660952670701-I5s.png)
    
2. **Vendedores:** na coluna de vendedores (lateral direita) veja o percentual da meta do período de cada membro da sua equipe de vendas.
3. **Indicadores de sucesso:** o Visão Geral disponibiliza os números dos seus indicadores de venda (ticket médio, peças por atendimento, taxa de conversão e usabilidade).
4. **Feedback:** só de bater o olho você sabe quantos feedbacks já foram realizados e quantos ainda não.
    
    ![](https://cdn.elev.io/file/uploads/PaTSwalD0CD1qzKrTIxoPy5YohxXp70Y2-RFBqKo7-Y/cRkSaBFqT-n854CvRm9NncSZTbmNZcLCbJ1ghDQPP2U/Snap%202019-08-09%20at%2011.14.20-S8I.png)
    
5. **Informações estratégicas:** tenha em mãos uma riqueza de gráficos: fluxo de atendimento: oportunidades e aproveitamento; evolução diária no mês dos indicadores, variação anual, motivos de perda de venda etc.

**Vale lembrar que todas as informações disponíveis na visão geral são atualizadas até o dia anterior.**

😉 **DICA -** Se quiser se aprofundar nas informações, não deixe de acessar o “Raio X” o relatório mais completo da Indeva! É só ir lá na área de relatório do menu lateral do painel. =)