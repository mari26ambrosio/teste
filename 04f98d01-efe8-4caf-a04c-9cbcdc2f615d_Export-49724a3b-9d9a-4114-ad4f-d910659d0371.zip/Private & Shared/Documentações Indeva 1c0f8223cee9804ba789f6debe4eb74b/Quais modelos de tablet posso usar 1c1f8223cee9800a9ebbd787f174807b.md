# Quais modelos de tablet posso usar?

Os totens (suportes do tablet) para uso do tablet na loja são personalizados para cada tipo de dispositivo. Caso você compre um tablet com um modelo diferente do totem que possui, o encaixe pode ficar comprometido.

Nossos modelos de tablet homologados para uso são:

**☑️ Samsung A7 Lite T220 (modelo mais novo)**

**☑️ Samsung Galaxy T290**

**☑️ Samsung Galaxy T295**

**☑️ Samsung Galaxy T560**

> 💡Dica: Somente os tablets listados acima são homologados para uso do aplicativo Indeva - Lista da Vez, então fique ligado! 😉
> 

> Importante: Recomendamos o uso dos totens apenas aos tablets que utilizam **Indeva - Lista da vez**. Para o aplicativo VTEX Sales App, que só pode ser instalado em versões acima do android 10, não temos recomendações de totens.
>