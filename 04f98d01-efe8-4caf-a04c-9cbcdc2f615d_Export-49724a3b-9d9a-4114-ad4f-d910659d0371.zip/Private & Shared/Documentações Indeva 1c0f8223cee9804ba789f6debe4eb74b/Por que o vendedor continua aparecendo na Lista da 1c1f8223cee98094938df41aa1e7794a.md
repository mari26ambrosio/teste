# Por que o vendedor continua aparecendo na Lista da Vez?

Em primeiro lugar, é preciso verificar se o cadastro dele já foi inativado. Para inativar um vendedor, entre em cadastros > vendedor > ações > férias ou inativar > **desligamento**.

Caso o desligamento já tenha sido realizado corretamente, Faça um dos procedimentos abaixo.

Indeva - Lista da vez:

1) Vá até o tablet e abra o App;

2) Clique no botão com 3 pontinhos no canto direito superior da tela;

3) Clique em **Forçar envio** e aguarde 3 segundos;

4) Clique em **Recarregar aplicação.**

VTEX Sales App:

1) Vá até o tablet e abra o App;

2) Clique no botão superior esquerdo (Menu)

3) Status do aplicativo

4) Atualizar dados

> ⚠️Atenção: Esse passo a passo deve ser feito sem nenhum vendedor na coluna de atendimento, ok?
>