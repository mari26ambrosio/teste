# Onde consigo informações sobre minhas faturas em aberto?

Para os usuários cadastrados para receber os boletos, a **área financeira** já está disponível no acesso web. Ele fica no canto superior direito, onde estão as informações do seu perfil.

![](https://cdn.elev.io/file/uploads/tBgen6l2bR68tnG4jliwz2r3Y7l43THZ1FPLchAS11w/KROJUErBVBwPt4AyQolTFNKuWhEU28Ray9qyH5kl3f0/1663369798998-Q1c.png)

Esse ambiente foi criado para ter **acesso rápido à 2ª via do boleto ou Nota fiscal** pagas/em aberto da loja, para os usuários que já recebem os boletos por e-mail.

Caso você não tenha acesso à área financeira, é preciso enviar uma mensagem diretamente para o time financeiro através do e-mail faturamento@indeva.com.br. O time financeiro vai poder ajudar com as suas dúvidas! 😉