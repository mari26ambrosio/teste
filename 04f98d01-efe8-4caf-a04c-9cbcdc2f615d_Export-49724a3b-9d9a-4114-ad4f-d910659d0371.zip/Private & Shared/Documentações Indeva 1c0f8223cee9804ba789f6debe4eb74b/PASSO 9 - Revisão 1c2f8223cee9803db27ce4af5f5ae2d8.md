# PASSO 9 - Revisão

A última etapa do cadastro de metas é a revisão de todas as informações registradas até então.

São elas:

- Ciclo da Meta e sua divisão em período.
- Valor total da meta cadastrada para, além da meta individual para cada vendedor.
- Distribuição de pesos, lineares ou diferentes.
- Frequência: existe uma meta cadastrada para cada dia do período ou folgas/feriados foram incluídos no planejamento?

![](https://cdn.elev.io/file/uploads/vvJa8Eygp4CZPDf4NGbPAIydeLJytLeTCol2pMkU-no/1cX5NrRYMdzyp4dWcoY1XaXgjrIfDrveMm1VzahpIlQ/indeva%209-cYs.PNG)

Para editar alguma dessas informações, clique no ícone do lápis ao lado da configuração desejada.

Por fim, clique no botão "Finalizar edição" para concluir o cadastro da meta 😉