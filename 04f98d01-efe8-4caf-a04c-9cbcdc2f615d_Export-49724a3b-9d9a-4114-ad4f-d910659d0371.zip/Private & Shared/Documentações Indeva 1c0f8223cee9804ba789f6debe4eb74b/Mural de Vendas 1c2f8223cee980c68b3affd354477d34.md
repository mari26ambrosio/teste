# Mural de Vendas

O mural de vendas é o relatório mais visual da Indeva!

![](https://cdn.elev.io/file/uploads/QBzHaXAsXxOVU9cJt8qy4K7_fCUmprAgEkSOPIaQEPs/13nb-BYWfJXVaQwDyxZjeO2xCxVQJSUd8Tz74sHNxms/Snap%202018-01-31%20at%2010.36.22-FZI.png)

Criamos uma **simbologia por cores** para facilitar a visualização da performance da sua equipe de vendas! Então, neste relatório você compara o **desempenho dos vendedores** em relação ao resultado da loja. Assim, só de bater o olho, fica fácil saber qual vendedor não está performando como o esperado.

Você acessa esse relatório assim:

> Entre no Menu da Indeva (na lateral esquerda) > 📄 Relatórios > Mural de vendas.
> 

![](https://cdn.elev.io/file/uploads/QBzHaXAsXxOVU9cJt8qy4K7_fCUmprAgEkSOPIaQEPs/YnOt-jtdque8in1A5Y0R7-pW3YLTpuaI7YdfEI0PPLM/gifmural-ftY.gif)

Você pode fazer o filtro por **"Mês"** ou por **"Períodos e Meses."**

Este mural é apresentado com carinhas que podem ser nas cores: **vermelha, amarela e verde** (podem variar de rede para rede)**.** Essa simbologia identifica, rapidamente, as posições das suas metas!

Para entender o significado de cada cor, a simbologia está representada no cabeçalho do relatório.