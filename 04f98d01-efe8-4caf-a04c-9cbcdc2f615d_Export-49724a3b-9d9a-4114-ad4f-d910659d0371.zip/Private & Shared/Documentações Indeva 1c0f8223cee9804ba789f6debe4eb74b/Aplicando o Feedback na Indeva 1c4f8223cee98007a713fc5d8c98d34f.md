# Aplicando o Feedback na Indeva

🎥Nesse **Webinar** apresentamos para você como aplicar o **Feedback** para os vendedores na plataforma **Indeva**.

Além disso compartilhamos como um bom feedback pode **ajudar a melhorar os indicadores de vendas da loja** e potencializar os seus resultados🤑!

Assista o vídeo e aprenda como aproveitar ao máximo esse recurso!

Assista por esse link:

[**https://youtu.be/xSSePee6bVg**](https://youtu.be/xSSePee6bVg) - Parte 1

[**https://youtu.be/JizK1nnZiJ0**](https://youtu.be/JizK1nnZiJ0) - Parte 2