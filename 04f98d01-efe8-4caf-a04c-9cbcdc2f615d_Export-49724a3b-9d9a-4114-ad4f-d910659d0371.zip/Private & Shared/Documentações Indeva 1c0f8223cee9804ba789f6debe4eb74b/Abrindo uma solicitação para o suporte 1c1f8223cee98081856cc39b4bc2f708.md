# Abrindo uma solicitação para o suporte

Os usuários com permissão para acessar o ambiente Web têm acesso a atendimento fornecido pelo time de especialistas do Atendimento Indeva.

Dentro do seu acesso gerencial, você contará com a ajuda da **Eva**, nossa inteligência artificial. Caso sua situação seja específica, ela vai criar uma solicitação para que o time de atendimento possa te apoiar.

> 💡É possível também acompanhar suas solicitações através do painel de ticket ([Clique aqui para saber mais](Painel%20de%20solicitac%CC%A7o%CC%83es%201c1f8223cee980e0b1b3fc8b6b402103.md))
> 

Este artigo traz nossas indicações de boas práticas de como abrir um chamado para o atendimento. É importante ter em mente dois pontos:

**1 - Cenário**: Trazer com detalhes qual a dificuldade que está encontrando na plataforma, formas de apontar os cenários. Exemplos:

- Estou enfrentando um problema ou um comportamento inesperado;
- Tenho uma dúvida e gostaria de fazer uma pergunta;
- Gostaria de solicitar uma configuração.

**2 - Evidências**: Levante as evidências do cenário que está trazendo, é importante ter em mente os seguintes pontos para construir suas evidências. Exemplos:

- **Qual ambiente?** App Lista da Vez, ambiente web;
- **Qual tela?** Na parte de Cadastro, nos relatórios, nos rankings, visão geral, integração;
- **Relacionado a uma loja**: Precisamos do CNPJ para identificar a loja;
- **Relacionado a um usuário**: precisamos do  ou  com acesso à web;
    
    CPF para identificar um vendedor
    
    e-mail para identificar um usuário
    
- **Mensagem de erro**: Quais mensagens que estão aparecendo;
- **Enviar fotos/vídeos** para ajudar a contextualizar o suporte sobre o cenário que está passando.

Com esses pontos em mente, você garante que os especialistas de atendimento entendam sua solicitação e te retornem de forma mais assertiva.