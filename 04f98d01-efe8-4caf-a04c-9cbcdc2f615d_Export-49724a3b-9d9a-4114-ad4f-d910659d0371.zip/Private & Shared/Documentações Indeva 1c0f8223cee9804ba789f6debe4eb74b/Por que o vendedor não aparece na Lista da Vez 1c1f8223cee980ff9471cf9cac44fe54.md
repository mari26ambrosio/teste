# Por que o vendedor não aparece na Lista da Vez?

Primeiro, verifique se o vendedor está ativo e possui meta cadastrada. Se ainda assim ele não estiver aparecendo na Lista da Vez, isso pode estar acontecendo devido a um cadastro recente, ou retorno de uma ausência temporária, como férias ou licenças, e o app ainda não atualizou as informações.

Nesse caso, é super fácil resolver! Faça um dos procedimentos abaixo:

Indeva - Lista da vez:

1) Vá até o tablet e abra o App;

2) Clique no botão com 3 pontinhos no canto direito superior da tela;

3) Clique em **Forçar envio** e aguarde 3 segundos;

4) Clique em **Recarregar aplicação.**

VTEX Sales App:

1) Vá até o tablet e abra o App;

2) Clique no botão superior esquerdo (Menu)

3) Status do aplicativo

4) Atualizar dados

> ⚠️Atenção: Esse passo a passo deve ser feito sem nenhum vendedor na coluna de atendimento, ok?
>