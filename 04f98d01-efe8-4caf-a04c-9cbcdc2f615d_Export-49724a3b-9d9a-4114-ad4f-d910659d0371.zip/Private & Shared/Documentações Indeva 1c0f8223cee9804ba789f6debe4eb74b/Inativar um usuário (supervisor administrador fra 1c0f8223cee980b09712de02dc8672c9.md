# Inativar um usuário (supervisor/administrador/franqueado

Na Indeva, usuários são todos aqueles que utilizam a plataforma mas não são gerentes nem vendedores. É o caso dos franqueados, supervisores, consultores, entre outros equivalentes.

Caso queira inativar um usuário, você deve abrir um chamado com o Suporte Indeva informando o usuário que deseja inativar.

> ⚠️Importante: o pedido de inativação deve ser feito por um usuário com acesso superior.
> 
> 
> Exemplo: para inativar um supervisor, é necessário autorização do franqueado ou do administrador da conta.
>