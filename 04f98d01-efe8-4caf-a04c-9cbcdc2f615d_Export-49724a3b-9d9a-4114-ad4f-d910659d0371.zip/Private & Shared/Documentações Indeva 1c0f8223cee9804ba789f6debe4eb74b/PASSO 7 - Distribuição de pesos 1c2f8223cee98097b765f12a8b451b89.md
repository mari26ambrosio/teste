# PASSO 7 - Distribuição de pesos

Agora você deve escolher como o valor total da meta deve ser distribuído entre os dias úteis desse ciclo.

Nesse caso, existem duas opções:

- Distribuição **linear**: o valor total será dividido igualmente entre os dias úteis do período.
- Distribuição com **pesos diferentes**: o valor total será dividido de acordo com porcentagens diferentes entre os dias úteis do período.

💡 Lembre-se: a distribuição só é válida para dias úteis do ciclo da meta.

---

Logo, para realizar esse passo do cadastro de metas:

1. Clique em **uma das opções** - **“Distribuição linear”** ou **“Distribuição com pesos diferentes”.**
2. Clique no **botão “Próximo”**.

![](https://cdn.elev.io/file/uploads/vvJa8Eygp4CZPDf4NGbPAIydeLJytLeTCol2pMkU-no/E0pDcaXxIS_ZaWOvTg6pg3I403KhxoiBwaRMmNP0DGY/indeva%205-HBw.PNG)

A partir daqui, o fluxo pode seguir dois caminhos diferentes.

**Distribuição linear**

Se você escolher a distribuição linear dos pesos, o sistema o encaminha para a última etapa do cadastro: a revisão de todas as informações registradas para aquela meta.

**Distribuição com pesos diferentes**

Caso você escolha a distribuição com pesos diferentes, o sistema o direciona para a etapa de configuração desses pesos.

Desse modo, você pode optar por configurar pesos por dia ou por períodos.

🧐 Fique ligado: tanto na configuração de pesos diários quanto na configuração de pesos por período, você pode importar os pesos do ano anterior.

---

**Preenchimento por cópia de documento externo**

Em ambas as configurações - pesos diários ou pesos por período -, você tem a opção de utilizar os dados de um documento externo para preencher os pesos.

Nesse caso, você pode copiar os valores e colá-los tanto na coluna de porcentagem quanto na de valores. Caso haja algum dado preenchido nas duas colunas, essas informações serão sobrescritas com os novos valores do documento externo.

As formas importar os dados de um documento externo são:

- Copiar os valores separados por ponto e vírgula: 100; 200; 300.
- Copiar os valores separados por espaço: 100 200 300.
- Copiar uma coluna inteira de uma planilha.
- Copiar uma linha inteira de uma planilha.

![](https://cdn.elev.io/file/uploads/vvJa8Eygp4CZPDf4NGbPAIydeLJytLeTCol2pMkU-no/u6LBNCKAfrlpKdSMD9BLJ6iVuIEzqP6Ahp2ETnNIysE/indeva%206-7TY.PNG)

🧐Fique ligado: ao fechar o box “Preenchimento por cópia de documento externo”, não é possível reabri-lo. Somente após a limpeza dos cookies do seu browser, este box será exibido novamente.

---

**Pesos diários**

Na configuração de pesos diários, o sistema calcula automaticamente a porcentagem que deve ser aplicada nos dias úteis de cada um dos ciclos da meta.

Você tem a opção de preencher cada um dos valores manualmente. Porém, é necessário que esses valores correspondam ao total cadastrado da meta informada para aquele ciclo.

![](https://cdn.elev.io/file/uploads/vvJa8Eygp4CZPDf4NGbPAIydeLJytLeTCol2pMkU-no/3jQ5ndfc_AgqT_NUUNNckr9Nz6AUt-OQEa3Hh7u3L_M/indeva%207-FO0.PNG)

🚨 Cuidado: caso os valores dos pesos atribuídos não somem o total cadastrado da meta do ciclo, não será possível concluir o cadastro.

---

Clique no botão “Próximo” para avançar para a próxima etapa do cadastro de metas.

**Pesos por período**

Se você optar por cadastrar pesos por período, o sistema também calcula automaticamente os pesos que devem ser atribuídos a cada período.

Por exemplo, se um ciclo foi dividido em dois períodos, você precisará atribuir dois pesos - um para cada.

Logo, ao final da configuração, a soma de todos os pesos deve resultar no valor total cadastrado para a meta.

![](https://cdn.elev.io/file/uploads/vvJa8Eygp4CZPDf4NGbPAIydeLJytLeTCol2pMkU-no/AJnNr0i5zPj-skySmMwmHGAqDIcNm4zgB3E4nR5-d7o/indeva%208-rZo.PNG)

Da mesma forma que a configuração de pesos diários, você pode atribuir pesos manualmente aos períodos do ciclo.

🚨 Cuidado: caso os valores dos pesos atribuídos não somem o total cadastrado da meta do ciclo, não será possível concluir o cadastro.

---

Clique no botão “Próximo” para seguir para última etapa do cadastro de metas.