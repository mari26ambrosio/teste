# Navegando na Área Financeira

> 🔒 Apenas os usuários autorizados a receber o boleto são capazes de acessar a Área Financeira. Caso não saiba onde encontrar a área, para solicitar o acesso envie um e-mail para faturamento@indeva.com.br
> 

A navegação da Área financeira é separada por status do título, são eles:

> ⚠️Atrasado: Boletos gerados que passaram da data de vencimento.📆 Aberto: Boletos gerados que vão vencer numa data futura.✅ Pago: Boletos gerados que já foram pagos.
> 

No canto superior você pode filtrar por:

🏬 **Lojas** *(caso seu usuário receba os boletos de mais de uma loja)*;

📆 **Mês vencimento**;

✨ **Ano de vencimento**.

👉*Também é possível consultar as Notas fiscais gerada para suas lojas.*

Abaixo um vídeo rápido em como navegar dentro do ambiente:

![](https://cdn.elev.io/file/uploads/tBgen6l2bR68tnG4jliwz2r3Y7l43THZ1FPLchAS11w/YWhRrQqunWMKKLJhC1eW13N5G2GVX2dO7zA5Jgs-XZA/Navegando%20na%20%C3%A1rea%20Financeira-pUw.gif)

> Caso queira alterar ou adicionar mais e-mails para acessar essa área, será preciso encaminhar um e-mail para
> 
> 
> **faturamento@indeva.com.br**
>