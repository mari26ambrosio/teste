# Como altero o formato de distribuição da meta (período ou mês)?

No cadastro da Meta existe 2 formatos de distribuição da meta, são eles: **Meta por mês** e **Meta por período** [**para mais detalhe confira por aqui**](PASSO%202%20-%20Controle%20do%20ciclo%20de%20meta%201c1f8223cee9805891c8e432c572e6d0.md).

Existe uma forma para editar caso precise alterar o formato da meta após cadastrada, você poderá fazer da seguinte forma:

1. Vá na tela de Cadastro de metas e clique na meta desejada em **Ações >** **Editar**.
2. Clique no botão **Editar duração da meta**
3. Clique em avançar e na tela seguinte clique em **Anterior**, e em seguida em **Anterior** novamente.

> ⚠️ Atenção: `Para a alteração refletir após avançar em todas as etapas do cadastro da meta, chegando até Finalizar edição.
> 

Abaixo um Gif exemplificando a forma de editar o ciclo da meta:

![](https://cdn.elev.io/file/uploads/tBgen6l2bR68tnG4jliwz2r3Y7l43THZ1FPLchAS11w/hl1dDb81RTG12vc3pqXnuVq5AAfXQuag1rZndtywGoQ/1666027969160-QzM.gif)

Assim, é possível alterar o que foi estipulado no ciclo.