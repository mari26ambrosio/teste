# Fluxo de Oportunidades (Relatório)

Descubra quais são os dias da semana e horários mais movimentados em sua loja!

Você acessa esse relatório assim:

> Entre no Menu da Indeva (na lateral esquerda) > 📄 Relatórios > Fluxo de oportunidades.
> 

Este relatório vai te ajudar a identificar, rapidamente, o dia da semana mais agitado no salão de vendas. Assim facilita a sua decisão ao criar ações de atração para a sua loja.

![](https://cdn.elev.io/file/uploads/QBzHaXAsXxOVU9cJt8qy4K7_fCUmprAgEkSOPIaQEPs/EozJ_Sh8pid_cpInMd-suP4iMznBJRqe2H5hmjHzbRE/1539007969022-V9g.png)

**Clique na imagem para aumentar a imagem**

Você também conseguirá acompanhar como foi a **taxa de conversão** através dos gráficos e tabelas que comparam a **quantidade de atendimentos** e **quantidades de conversões.**

Você encontra mais detalhes sobre os gráficos de [**fluxo de oportunidade**](Fluxo%20de%20Oportunidades%201c2f8223cee980369f89d7be58b152cb.md) e [**fluxo de aproveitamento](Fluxo%20de%20Aproveitamento%201c2f8223cee980e29d5be09ac756fb82.md)** clicando nos nomes :)

👉**Dica -** Coloque o mouse em cima dos pontos de pico no gráfico e você terá a informação. (Veja exemplo na imagem acima)

⚠️ **Atenção -** Utilize o botão "Filtrar dados" para selecionar o período que deseja. E no campo "Dias da semana" caso queira selecionar algum dia da semana separadamente.