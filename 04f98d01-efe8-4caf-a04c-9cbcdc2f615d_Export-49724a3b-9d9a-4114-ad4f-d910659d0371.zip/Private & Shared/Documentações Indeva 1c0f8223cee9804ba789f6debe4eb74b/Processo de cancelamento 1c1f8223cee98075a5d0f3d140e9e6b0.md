# Processo de cancelamento

![](https://cdn.elev.io/file/uploads/vvJa8Eygp4CZPDf4NGbPAIydeLJytLeTCol2pMkU-no/GTePsx0YzI01072R-mQyN8CuH8iIcA0hta4OlzIGw7M/1655497540308-2FE.png)

O contrato da Indeva é relacionado ao **ambiente da loja**. Então, caso haja encerramento das operações, repasse para novo franqueado, troca de CNPJ ou qualquer outra questão relacionada, basta solicitar o cancelamento e informar o motivo ao nosso time.

Para iniciar o processo de cancelamento, é preciso sinalizar com **30 dias de antecedência** e preencher o formulário de cancelamento, através [**deste link**](https://indeva.zendesk.com/hc/pt-br/requests/new), preenchendo de acordo com os campos.

> ⚠️Importante: Na propriedade "Tipo de solicitação" é preciso selecionar a opção "Cancelamento" para aparecer o formulário correto.
> 
> 
> ![](https://cdn.elev.io/file/uploads/tBgen6l2bR68tnG4jliwz2r3Y7l43THZ1FPLchAS11w/DC1qoR8Dh45eXf9JyxNtTMO3PThjDOM2uddyMNkQkQ0/1670439126820-VR8.png)
> 

Depois disso, é só aguardar o retorno do time responsável fará o retorno por e-mail para seguir com o processo de cancelamento.

> ⚠️: Por nossa ferramenta ser no modelo SAAS, todos os dados presentes em relatórios são removidos após a data de inativação. Caso queira manter os dados, recomendamos que exporte as informações que achar importante antes da inativação.
>