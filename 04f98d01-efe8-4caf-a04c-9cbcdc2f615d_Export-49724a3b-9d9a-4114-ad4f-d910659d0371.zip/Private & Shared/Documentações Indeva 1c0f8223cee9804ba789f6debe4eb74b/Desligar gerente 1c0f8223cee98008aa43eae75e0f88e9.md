# Desligar gerente

> ⚠️ Apenas usuários com o perfil**, Franqueado ou Administrador**
> 

![](https://cdn.elev.io/file/uploads/QBzHaXAsXxOVU9cJt8qy4K7_fCUmprAgEkSOPIaQEPs/oYICf0tF1P0j93M82Fc86sexgAKGlO_z0LpI6wwHLlw/question-698.png)

Para ativar um gerente da loja é simples!

> Entre no Menu (na lateral esquerda) > Cadastro > Gerentes ” .
> 

Clique em " **Ações " ,** "Férias ou **I nativa** ". Clique em " **Desligamento** ", selecione o " **motivo do desligamento** " ea " **data do desligamento é o último dia de trabalho** ".

![](https://cdn.elev.io/file/uploads/tBgen6l2bR68tnG4jliwz2r3Y7l43THZ1FPLchAS11w/OyCVRwED3bhXq7FNe5Tq9osT-spKoiE-397b9_e3UKM/1660652225733-aa0.png)

**😉DICA -** Fique atento na hora de preencher a dados de desligamento do gerente **não** é possível editá-lo depois!

> ✨ Já desligou seu gerente e precisa cadastrar o novo? Após ativar o antigo gerente, será preciso cadastrar o novo.
> 
> 
> 🔎 [**Como cadastrar o gerente**](Cadastro%20de%20gerente%201c0f8223cee9804792bad520d9592384.md)
>