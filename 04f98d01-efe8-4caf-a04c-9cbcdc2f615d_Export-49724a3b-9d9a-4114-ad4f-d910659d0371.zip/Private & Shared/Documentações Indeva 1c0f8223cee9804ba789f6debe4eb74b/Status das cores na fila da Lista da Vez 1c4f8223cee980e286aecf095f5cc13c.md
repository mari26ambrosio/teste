# Status das cores na fila da Lista da Vez

Para algumas situações no atendimento da **Lista da Vez Indeva** uma bolinha colorida é atribuída ao vendedor e cada cor tem uma finalidade.

As cores na fila da vez são relacionadas aos motivos disponíveis na **marcação do atendimento** do vendedor.

Essas opções aparecem de acordo com a configuração de cada loja e podem variar de uma para outra, atendendo a sua necessidade particular.

Entenda o motivo de cada uma delas:

❤ **Vermelha:** indica que o vendedor voltou para a lista da vez cancelando um atendimento (o motivo do cancelamento pode ser verificado no histórico diário do relatório da lista da vez).

💛**Amarela:** é vinculada quando o vendedor realiza uma reserva de outro vendedor.

🧡 **Laranja** indica que o vendedor estava em segundo lugar em diante no atendimento mas precisou sair para realizar alguma atividade interna (como estoque ou operacionais).

💚**Verde:** quando o vendedor está em atendimento por preferência do cliente.

💙 **Azul:** indica retorno do cliente à loja.

💜**Roxa:** indica que o vendedor realizou uma troca sucesso.

🖤 **Preto:** indica que o vendedor está em sua posição sem alteração nenhuma (mesmo que tenha vendido e/ou realizado alguma troca).