# Relatório Lista da Vez

🎥 Nesse **Webinar** apresentamos o novo formato do **Relatório Lista da Vez** **Indeva**.

Assista o vídeo através do link abaixo, e conheça as funcionalidades e como esse relatório pode te ajudar na gestão da loja!

Link do vídeo: [**https://youtu.be/UEv7unUF2vE**](https://youtu.be/UEv7unUF2vE)