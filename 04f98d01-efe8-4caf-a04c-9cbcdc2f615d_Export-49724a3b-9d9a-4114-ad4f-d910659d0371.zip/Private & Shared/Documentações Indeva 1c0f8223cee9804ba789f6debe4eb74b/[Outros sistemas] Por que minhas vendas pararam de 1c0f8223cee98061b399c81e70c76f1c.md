# [Outros sistemas] Por que minhas vendas pararam de subir para a Indeva?

Este artigo se refere às integrações com os sistemas abaixo:

- **Linxpos**
- **Alterdata**
- **Cigam**
- **Interfacenet**
- **Falcon**
- **PDVNet**

A integração da Indeva com esses sistemas é feita **diretamente no servidor da loja** por meio do programa “**Integrador Indeva**” consultando as vendas no banco de dados da loja e alimentando a plataforma web com os valores corretos.

Há duas situações comuns que causam essa falha na integração:

1. **O Integrador tem de estar aberto em segundo plano para realizar a integração**, e é possível que alguém o tenha fechado sem saber disso. Verifique na setinha no canto inferior direito da tela se o ícone da Indeva está aparecendo. Caso não esteja, abra o menu inicial e pesquise pelo programa. Se encontrar, abra ele e clique na frase em azul “Esconder Integrador”. Mesmo se reiniciar o computador, ele continuará funcionando até alguém fechá-lo manualmente.
2. Caso o Integrador tenha sumido do computador, **verifique a parte de “quarentena” do seu antivírus.** O Integrador Indeva é seguro, mas não é identificado como um programa homologado pelo Windows, o que faz com que o antivírus o ache suspeito. Um arquivo que compõe o integrador chamado ‘IDP.generic’ normalmente fica em quarentena, e você pode restaurá-lo abrindo uma exceção. Após isso, procure o integrador Indeva no menu inicial, abra o programa e clique na frase em azul “Esconder Integrador”.