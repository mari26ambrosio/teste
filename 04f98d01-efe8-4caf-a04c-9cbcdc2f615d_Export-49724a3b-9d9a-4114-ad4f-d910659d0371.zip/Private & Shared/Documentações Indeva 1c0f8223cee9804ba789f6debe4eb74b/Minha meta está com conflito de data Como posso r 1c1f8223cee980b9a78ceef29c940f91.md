# Minha meta está com conflito de data. Como posso resolver?

Na Indeva, só é possível cadastrar uma meta por cada ciclo. Ou seja, a meta seguinte só pode começar quando a meta anterior tiver acabado. Por isso, quando se inclui em uma meta um dia que já está cadastrado em outra meta, aparece uma mensagem de conflito.

Para evitar o conflito, confira os seguintes pontos:

**1) Já existe uma meta cadastrada para o ciclo atual?**

Caso exista uma meta cadastrada para o ciclo atual, com a mesma data de início e data de fim, você deve simplesmente editar a meta já criada clicando em ações > **editar**.

**2) A nova meta começa depois do término da última meta?**

Caso a nova meta atravesse o ciclo de meta anterior, você precisará ajustar a nova meta para que ela comece somente depois que a última meta terminar.

> Exemplo: se o ciclo da primeira meta é de 01/07/2022 a 31/07/2022, a meta seguinte só pode começar no dia 01/08/2022, depois do fim da anterior.
> 

**3) Já existe uma meta cadastrada com o mesmo mês de referência?**

Caso já exista uma meta cadastrada com o mesmo mês de referência, você precisa cadastrar a nova meta com outro mês de referência.

> Exemplo: existe uma meta cadastrada para o mês de referência 07 (julho). Nesse cenário, só será possível cadastrar uma nova meta com o mês de referência seguinte, que no caso é 08 (agosto).
> 

> 💡Fique ligado: em casos onde o ciclo mensal contempla dois meses diferentes, você deve definir como o mês de referência aquele que tiver mais dias dentro do ciclo da meta!
>