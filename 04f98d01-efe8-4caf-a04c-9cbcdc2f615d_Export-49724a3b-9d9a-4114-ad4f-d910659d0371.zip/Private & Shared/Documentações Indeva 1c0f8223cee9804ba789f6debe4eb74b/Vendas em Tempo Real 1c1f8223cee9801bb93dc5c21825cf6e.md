# Vendas em Tempo Real

> ⚠️ Importante: A integração das vendas realmente não ocorre necessariamente em tempo real.
> 

![](https://cdn.elev.io/file/uploads/5G0ie0odcvxxzlQJCL8hk63Tz97zk9dh4tLJhVkC1lk/p1AzqRrqGqQyvx136Eg0T09aniRVm97h7tzUSqHBkTw/1705599104319-TX0.png)

Em alguns casos, os dados só vão aparecer consolidados mesmo ao final do dia, pois a integração das vendas depende de alguns fatores, inclusive do próprio PDV. São feitas várias tentativas de atualização ao longo do dia, e alguma delas provavelmente irá funcionar.

![](https://cdn.elev.io/file/uploads/5G0ie0odcvxxzlQJCL8hk63Tz97zk9dh4tLJhVkC1lk/qUb-MgQVch85su8CXb628RN5zax1gR95MJ4z_VoGBHc/1705599006293-GNU.png)

> 👉️ Dica: O ideal é que você confira no final do dia, ou até mesmo na manhã seguinte.
> 

Se na manhã seguinte as vendas ainda não tiverem integrado, então realmente há um problema. Nesse caso, você pode entrar em contato com o suporte da Indeva que analisamos o problema.