# PASSO 4 - Divisão do ciclo da meta em períodos

Uma vez definida a duração total da meta, o próximo passo é definir em quantos períodos você deseja dividir esse ciclo.

Desse modo, siga os passos a seguir:

1. Na seção **“Períodos”**, clique no **número correspondente à quantidade de períodos** que você deseja criar para o ciclo da meta.
    
    ![](https://cdn.elev.io/file/uploads/vvJa8Eygp4CZPDf4NGbPAIydeLJytLeTCol2pMkU-no/XTg_qUnOmGY6eqDb7NaMD4ljHCcn5Er3GhipNVbYQSk/1621005852603-fE4.png)
    
2. Em seguida, defina **quantos dias o primeiro período deve ter** clicando nos botões "-" e "+".

🧐 Fique ligado: quando você configura a duração do primeiro ciclo, a duração dos demais ciclos se adequa ao restante dos dias que sobrarem do ciclo da meta.

---