# [Microvix - usuário e senha] Por que minhas vendas pararam de subir para a Indeva?

Em **Novembro.2022** a Indeva não está mais prestando suporte para o tipo de **integração usuário e senha Microvix**.

Essa integração conectava a partir de um usuário da loja e periodicamente era necessário informar a nova senha para que as informações de venda fossem enviadas no dia seguinte.

Para as lojas que utilizavam essa integração, recomendamos as seguintes alternativas:

**1 - Integração via Webservice key**: Essa integração é a mais recomendada para manter a atualização automática. Recomendamos conferir com o seu time técnico com o suporte da Linx se esse serviço já está incluso ou a contratação para obter esse recurso.

Para criar a integração via webservice key, é preciso fazer o contato com o nosso time de atendimento para parametrizar a nova integração.

**2 - Validação manual:** A validação manual é a forma de manter sua loja atualizada sem a necessidade de utilizar uma integração.

> [**Clique aqui**](Validac%CC%A7a%CC%83o%20manual%201c0f8223cee9805aa4adee5d05ba5945.md) para saber mais como realizar a validação.
>