# [VTEX Sales App] Erro: Usuário Bloqueado

> O VTEX Sales App é o aplicativo presente para todos os equipamentos que têm o Android com a **versão igual ou superior ao 12.**
> 
> 
> ![](https://cdn.elev.io/file/uploads/5G0ie0odcvxxzlQJCL8hk63Tz97zk9dh4tLJhVkC1lk/acP-y5VPIpgTXb_cecPb-f8zyLhMLwm4LiIRCKigHJg/1688759997827-qac.png)
> 

O erro “usuário bloqueado” acontece quando o usuário digita a senha incorretamente 3 vezes. Se você já errou a senha, criou uma nova e mesmo assim se deparou com esse erro, fique sabendo que a solução é bem simples.

![](https://cdn.elev.io/file/uploads/5G0ie0odcvxxzlQJCL8hk63Tz97zk9dh4tLJhVkC1lk/OhAsySMx1OGs-4Z5M96k9frl6Yv8kUp7H9F8BPNKN1k/1685125508868-1v8.png)

Para resolver esse erro, você deve ir no mesmo link que os usuários do inStore usam para criar a senha pela primeira vez: [**https://indevaclients.myvtex.com/admin**](https://indevaclients.myvtex.com/admin). Coloque lá o e-mail e a senha corretas

Surgirá um CAPTCHA para você verificar que não é um robô, e liberar sua conta. É só clicar e esperar o ✅ aparecer.

![](https://cdn.elev.io/file/uploads/5G0ie0odcvxxzlQJCL8hk63Tz97zk9dh4tLJhVkC1lk/VxdV-eSB8tkVOYfCA9EclEm9_0XKcBPVlfiNtOwPtM8/1680014524011-7pA.png)

Clique em “continuar”. Se aparecer a mensagem de “Você não tem permissão para acessar a página” é sinal de que deu tudo certo e sua conta foi liberada! Feche a página e volte para o VTEX Sales App no tablet.

![](https://cdn.elev.io/file/uploads/5G0ie0odcvxxzlQJCL8hk63Tz97zk9dh4tLJhVkC1lk/K3U6xBTe96qhl5LfFHZQmFuXzmAhmwKFTyv_fkb3ExQ/1680014524509-uWw.png)

Só tentar fazer login novamente, e problema resolvido!