# Acessando a Área Financeira

Você pode acessar a área financeira para ter rápido acesso a 2ª via de boletos e Notas Fiscais da assinatura Indeva e também acompanhar seu histórico de assinaturas.

> 🔒Esse ambiente está disponível
> 
> 
> **apenas para usuários que recebem o boleto por e-mail**
> 

A Área Financeira está disponível no acesso web **apenas dos responsáveis financeiros cadastrados**. Fica no canto superior direito, onde fica as informações do seu perfil.

![](https://cdn.elev.io/file/uploads/vvJa8Eygp4CZPDf4NGbPAIydeLJytLeTCol2pMkU-no/tI_w5u6XaRoPrFW1X7L7pT-kwQ9BBqiTNOvQH6SSVFA/1655474130971-ED8.gif)

> Caso queira alterar ou adicionar mais e-mails para acessar essa área, basta encaminhar um e-mail para faturamento@indeva.com.br informando o CNPJ e o e-mail que gostaria de adicionar/remover.
>