# Gerente de Férias

Para colocar um gerente de férias na Indeva é fácil!

> Entre no Menu (na lateral esquerda) > Cadastro > Vendedores ”.
> 

Clique em "**ações**", "**Férias** **ou inativar**". Conforme abaixo:

![](https://cdn.elev.io/file/uploads/QBzHaXAsXxOVU9cJt8qy4K7_fCUmprAgEkSOPIaQEPs/-Ch-pVry6Kocsz4AVPKTw4JYHcZ8VTONNLLBsFQZdsQ/Snap%202018-11-23%20at%2016.02.57-KRk.png)

Clique em **"Ausência temporária"**, selecione o **"motivo da ausência"** que neste caso é **"Férias",** e **as datas de saída e de retorno das férias**.

**😉 DICA -** Fique atento na hora de preencher a data de saída e retorno das férias do gerente, **não** é possível editá-la depois!