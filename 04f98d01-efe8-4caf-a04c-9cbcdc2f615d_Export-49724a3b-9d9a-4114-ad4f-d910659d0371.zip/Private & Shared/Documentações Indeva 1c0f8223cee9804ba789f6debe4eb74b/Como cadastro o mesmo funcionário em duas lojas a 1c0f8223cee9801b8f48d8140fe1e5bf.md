# Como cadastro o mesmo funcionário em duas lojas ao mesmo tempo?

É comum que um funcionário trabalhe em mais de uma loja do mesmo grupo, e a Indeva inclui esse tipo de funcionário através da alteração do tipo de cadastro na segunda loja!

Se você deseja cadastrar um vendedor/gerente da sua **loja 1** na sua **loja 2**, é só **cadastrá-lo como vendedor/gerente temporário na 2ª loja**, seguindo este tutorial aqui: 👉[**Vendedor Temporário**](Vendedor%20Tempora%CC%81rio%201c0f8223cee98026a85edddb81cd915f.md)