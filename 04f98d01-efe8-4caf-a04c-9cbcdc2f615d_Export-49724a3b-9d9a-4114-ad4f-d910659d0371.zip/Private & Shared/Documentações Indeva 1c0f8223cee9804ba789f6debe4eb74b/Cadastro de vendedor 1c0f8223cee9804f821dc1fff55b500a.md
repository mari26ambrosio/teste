# Cadastro de vendedor

![](https://cdn.elev.io/file/uploads/QBzHaXAsXxOVU9cJt8qy4K7_fCUmprAgEkSOPIaQEPs/LyH_tC_lpDlrGxgihY6Hjhnf7q6ss-i48voY4KtOOTk/question-1UQ.png)

Para cadastrar um novo vendedor é simples,

**é só seguir o passo a passo**:

> Vá até o Menu (na lateral esquerda) > Cadastro > Vendedores > Clicar no botão (verde) “Cadastrar Vendedor”. As informações necessárias para o cadastro são:
> 

👉 Foto de vendedor

👉 CPF

👉 Nome completo

👉 Nome para exibição no sistema

👉 Sexo

👉 Data de nascimento

👉 Tipo (tipo de contratação: fixo ou temporário)

👉 Data início

👉 Data término (término do contrato de experiência ou do período temporário)

👉 Senha do vendedor no tablet

👉 Código do vendedor (o código que identifica o vendedor no sistema de PDV da Loja)

Para salvar, clique em “Cadastrar Vendedor” e pronto!😉