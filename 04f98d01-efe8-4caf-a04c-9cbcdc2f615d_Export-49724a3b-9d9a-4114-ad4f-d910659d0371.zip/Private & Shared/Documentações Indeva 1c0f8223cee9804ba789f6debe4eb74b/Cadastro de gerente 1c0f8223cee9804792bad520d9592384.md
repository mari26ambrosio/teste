# Cadastro de gerente

> Apenas usuários com o perfil de Supervisor, Franqueado ou Administrador tem permissão para realizar esse processo.
> 

![](https://cdn.elev.io/file/uploads/QBzHaXAsXxOVU9cJt8qy4K7_fCUmprAgEkSOPIaQEPs/LyH_tC_lpDlrGxgihY6Hjhnf7q6ss-i48voY4KtOOTk/question-1UQ.png)

Para cadastrar um novo gerente é simples,

**é só seguir o passo a passo**:

> Ir no Menu (na lateral esquerda) > Cadastro > Gerentes > Clique no botão (verde) “Cadastrar Gerente”. As informações necessárias para o cadastro são:
> 

👉 Foto do gerente

👉 CPF

👉 Nome completo

👉 Nome para exibição no sistema

👉 E-mail

👉 Sexo

👉 Data de nascimento

👉 Tipo (tipo de contratação: fixo ou temporário)

👉 Data início

👉 Data término (término do contrato de experiência ou do período temporário)

> ⚠️ Atenção: O cadastro na Indeva é único e intransferível e indicamos, para segurança das informações, o desligamento/transferência dele da loja caso haja qualquer alteração nos acessos
> 
> 
> 🔎 [**Como desligar o gerente**](Desligar%20gerente%201c0f8223cee98008aa43eae75e0f88e9.md)
> 

Para salvar, clique em “**Cadastrar gerente**”! Após realizar o cadastro o acesso ao site só estará liberado após a data de início informada e o usuário vai precisar criar uma senha de acesso a plataforma, [**consulte aqui**](Cadastrar%20senha%20Redefinir%20senha%20para%20o%20acesso%20a%CC%80%20I%201c0f8223cee980498454ef18a27258fa.md) como cadastrar a primeira senha! 😉