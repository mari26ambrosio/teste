# Passo 1: Criando o Formulário

Confira como incluir um novo Formulário:

Na Indeva, clique na opção **"Formulários"** e no botão **"Novo Formulário"**.

![](https://cdn.elev.io/file/uploads/vvJa8Eygp4CZPDf4NGbPAIydeLJytLeTCol2pMkU-no/ieYofll8ZgweAYLmTd1WvEXd9aPsln5FwSagVNCY8qo/1597339574511-UAk.png)

1. Preencha o **título** do formulário. "Ex.: Acompanhando gerencial Julho/2020"

2. As perguntas podem ser abertas e na quantidade necessária, só clicar em adicionar nova pergunta.

3. O ícone de anexo permite incluir arquivos, para orientação, fotos, entre outros.

4. Ao terminar de preencher as perguntas clique em **configurar envio**.

![](https://cdn.elev.io/file/uploads/vvJa8Eygp4CZPDf4NGbPAIydeLJytLeTCol2pMkU-no/juQ0ZL7krtiCDrC8oDXR1z2HsVSoKbxdR6ebGQWsrQk/1597339908460-lAw.png)

5. O campo **referência** indica qual mês, ou mês período será utilizado para o formulário.

6. A **regra de envio** define qual cenário deve ser filtrado, maior ou menor do que o percentual indicado, de acordo com o objetivo.

7. **Prazo para resposta** indica o limite de data que o gerente/VR precisa responder o Formulário.

8. No campo de **lojas** a plataforma aponta quais lojas estão dentro do filtro realizado que vão receber o formulário para resposta. Nesse momento o gestor pode desmarcar alguma loja no checkbox.

9. Ao terminar a conferência, clique no botão "**enviar formulários**". O processo estará concluído.😊