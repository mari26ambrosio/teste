# Transferir vendedor de loja

Muitas vezes, precisamos transferir um vendedor de uma loja para outra. Independente de ser uma transferência temporária ou definitiva, você deve seguir o passo a passo abaixo.

Em primeiro lugar, você precisa se certificar se o cadastro do vendedor já foi desligado na antiga loja.

Para desligar o vendedor da loja de origem, você deve seguir este caminho: **Cadastros > Vendedores > Ações > Férias ou Inativar > Desligamento**.

> ⚠️Importante: a data de início dele em sua loja não pode coincidir com o período que ele esteve ativo por lá! Por exemplo, se o cadastro dele ficou ativo na outra loja até o dia de hoje, você só conseguirá cadastrá-lo em sua loja a partir da data de amanhã!
> 

Feito isso, agora é só cadastrar o vendedor na nova loja!

Para cadastrar na nova loja: **Cadastros > Vendedores > Cadastrar vendedor**. ****Não se esqueça de cadastrar uma data de início posterior à data de desligamento da loja de origem, combinado?