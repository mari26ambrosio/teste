# Validação manual

![](https://cdn.elev.io/file/uploads/QBzHaXAsXxOVU9cJt8qy4K7_fCUmprAgEkSOPIaQEPs/D-XVQLLBZxaCsrMGUSrsoffi4KedkRD007jkDbAbk44/question-ICo.png)

Para que os relatórios da **Indeva** estejam corretos, é preciso inserir diariamente os valores do seu PDV no Indeva. Chamamos esse **lançamento dos valores** de **“✔️ Validação manual”**!

![](https://cdn.elev.io/file/uploads/PaTSwalD0CD1qzKrTIxoPy5YohxXp70Y2-RFBqKo7-Y/3_J6Hzc6acttZd6q9F8WhXdROV6ScIUH5kdnjCMTMhM/Snap%202019-08-12%20at%2010.27.04-x08.png)

> ⚠️ **Importante:**  Caso seu acesso tenha **mais de 1 loja** é necessário selecionar a loja no botão **Filtros** que se localiza no canto superior direito.
> 
> 
> ![](https://cdn.elev.io/file/uploads/vvJa8Eygp4CZPDf4NGbPAIydeLJytLeTCol2pMkU-no/lCi1oBUz5fUYdWIKoSp-3EgfDTspPaDSGt8GlCRjw4Y/1630421263340-MHc.png)
> 

**Como fazer:**

Clique em “**Validação**” (conforme indicado na imagem acima), escolha o dia e clique em “validar”. Abrirá uma tela para preencher os valores de vendas:

![](https://cdn.elev.io/file/uploads/QBzHaXAsXxOVU9cJt8qy4K7_fCUmprAgEkSOPIaQEPs/ZCMYhl1VfckVBsjUg_HMSpzjRY2mLq3WgEG18pOr7xw/Snap%202018-01-15%20at%2011.52.55-WTw.png)

Por fim, ao finalizar os lançamentos, clique em **“Salvar e Validar”.**

Após qualquer edição manual, a plataforma **bloqueia automaticamente as informações** inseridas para impedir futuras atualizações com a integração automática.

👉 A **Indeva** exibe também o **status** da última atualização manual: dia, horário e usuário que editou. =)

**😉 DICA -** Para evitar erros, é importante fazer esta validação sempre no dia seguinte.