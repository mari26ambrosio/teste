# Por que o vendedor cadastrado ainda não apareceu na visão geral?

A página de Visão Geral reúne os dados acumulados do seu ciclo mensal vigente, **considerando somente os dias já finalizados da meta atual**. Ou seja, a Visão Geral reúne desde o primeiro dia da meta até o dia anterior ao atual.

Por isso, o vendedor só aparecerá na visão geral caso tenha feito vendas em um dia já finalizado na meta atual.