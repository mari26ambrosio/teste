# Fluxo de Oportunidades

A Indeva possui um relatório completo que avalia em qual momento a sua loja recebe o maior número de clientes.

Você acessa esse relatório assim:

> Entre no Menu da Indeva (na lateral esquerda) > 📄 Relatórios > Fluxo de oportunidades.
> 

No gráfico de “**Fluxo de Oportunidades”** você observa o comparativo da **quantidade de atendimentos marcados no tablet** *versus* **quantidade de conversões** (de hora em hora).

### **Gráfico Fluxo de Oportunidades**

![](https://cdn.elev.io/file/uploads/QBzHaXAsXxOVU9cJt8qy4K7_fCUmprAgEkSOPIaQEPs/kkAy2C_qr_c_QnHpTIQ5RNvMEdYY1mXTEcVRF0pe9qQ/gr%C3%A1fico-DYs.png)

Essas informações te ajudam a rever a escala do time de vendas de acordo com os horários de maior movimento da loja.

😉 **Dica -** Coloque o mouse em cima dos pontos de pico no gráfico e você terá a informação do número de atendimentos e conversões. (Veja exemplo)

![](https://cdn.elev.io/file/uploads/QBzHaXAsXxOVU9cJt8qy4K7_fCUmprAgEkSOPIaQEPs/iW1q1h9hWl9o0TojHu9XwwTAmSybO0hrrpQYBEhgcd0/Snap%202018-01-30%20at%2015.21.45-khM.png)

⚠️ **Atenção -** É preciso filtrar a data início e fim antes de acessar as informações de qualquer relatório. =)