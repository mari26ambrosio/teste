# Vendedor Temporário

![](https://cdn.elev.io/file/uploads/QBzHaXAsXxOVU9cJt8qy4K7_fCUmprAgEkSOPIaQEPs/g2bRtsYf0XrJfKOs-y0GZw3DF-FNIk_E5N0mks3XAn4/question-9ts.png)

Para cadastrar um vendedor temporário acesse a área de cadastro de vendedor, conforme o passo a passo:

> Ir no Menu (na lateral esquerda) > Cadastro > Vendedores >Clique no botão (azul) “Cadastrar Vendedor”.
> 

Preencha as informações do vendedor, e em **"tipo"** de contratação do vendedor, selecione **"temporário"** e informe a “**data início e data término**”. Conforme imagem abaixo:

![](https://cdn.elev.io/file/uploads/QBzHaXAsXxOVU9cJt8qy4K7_fCUmprAgEkSOPIaQEPs/Gv_d2kXMjRVhlCoAR-ovTOnEIjvDEIr1zfeBCYsUXpc/image%20(1)-sIs.png)

Para salvar, clique em “Cadastrar Vendedor” e pronto!😉