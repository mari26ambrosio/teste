# Feedbacks (Relatório)

Acompanhe no **Relatório de Feedback** a quantidade de *feedbacks* já realizados e não realizados.

Você acessa essas informações assim:

> Entre no Menu da Indeva (na lateral esquerda) > 📄 Relatórios > Feedbacks.
> 

Veja, por vendedor, as informações:

- *Feedbacks* disponíveis
- A quantidade de *Feedbacks* já realizados e os ainda não realizados
- Percentual realizado
- Número de elogios e orientações

**⚠️ Atenção -** O cadastro de *feedback* está vinculado ao final de cada período configurado na meta, e o *feedback* de vendedores é sempre referente ao período imediatamente anterior.

**Exemplo**: A meta de uma loja é divida em 3 períodos. O feedback do 1º período para os vendedores só pode ser preenchido durante o período seguinte, ou seja, durante o 2º período. Quando o 3º período começar, o feedback do 2º período poderá ser preenchido, mas o feedback do 1º período ficará indisponível por ser muito antigo.