# Painel de solicitações

Ao fazer contato com o time de atendimento, suas dúvidas e solicitações ficam registradas no painel de solicitações.

> Você encontrará seus chamados com os times de Suporte/Financeiro:
> 
> 
> ![](https://cdn.elev.io/file/uploads/5G0ie0odcvxxzlQJCL8hk63Tz97zk9dh4tLJhVkC1lk/ekJ_5TYy2KRaf4P2OS0pU49VymMShVofYIa2W0JFG7s/1680096359983-7S4.gif)
> 
> [**Solicitações – Help Indeva**](https://indeva.zendesk.com/hc/pt-br/requests)
> 

Nele, é possível conferir as suas solicitações e acompanhar cada status.

![](https://cdn.elev.io/file/uploads/tBgen6l2bR68tnG4jliwz2r3Y7l43THZ1FPLchAS11w/2Fq-gKLLA9VgOX6nTRdgoIusPVR4IYIqYNHy9i3THnI/1671711641239-2Vo.png)

É preciso ter um **perfil de acesso** no ambiente Web Indeva para a abertura e tratativa dos chamados.

> Atenção: O painel de solicitações é para acompanhar as solicitações já abertas - o processo de abertura é feito pela Eva.
> 
> 
> [**Saiba como aqui**](Conversando%20com%20a%20Eva%20Abrindo%20um%20ticket%20com%20o%20Supo%201c1f8223cee980a8b1b2f68a7c26371d.md)
>