# [Erro] Conexão recusada no IP e/ou porta

Geralmente esse erro ocorre após o computador ter sido formatado ou quando foi feito a compra de um novo computador.

Nos casos de integração Desktop com o SQL Server em que a conexão no Ip/porta é recusada, tal como na imagem abaixo, deve-se habilitar a conexão TCP/IP pelo Manager.

![](https://cdn.elev.io/file/uploads/5G0ie0odcvxxzlQJCL8hk63Tz97zk9dh4tLJhVkC1lk/p7Dasrv80TCWHRoRrM994bTzAXJxHnas6DBEOl4QQbg/doc2-JJM.png)

O primeiro passo é abrir o SQL Server Configuration Manager:

![](https://cdn.elev.io/file/uploads/5G0ie0odcvxxzlQJCL8hk63Tz97zk9dh4tLJhVkC1lk/z8VQlcTGxj5gkST0kuEW0SoE80umtjnDNzbnxsy7sV8/doc1-sfA.png)

Caso o **SQL Server Configuration Manager** não apareça nas opções do menu Iniciar, pode ser encontrado no endereço C:\Windows\SysWow64\SQLServerConfigurationManager. É importante atentar que podem haver casos em que há duas versões do **SQL Server** e do **SQL Server Configuration Manager** no computador/servidor. Geralmente a versão correta é a mais atual, mas a melhor maneira de descobrir é testando. Abaixo um exemplo de duas versões do SQL Manager no computador da loja:

![](https://cdn.elev.io/file/uploads/5G0ie0odcvxxzlQJCL8hk63Tz97zk9dh4tLJhVkC1lk/srgocj0MH9NFZxWll1V6VWyf_NMwc2LYuFSnIE_x61o/manager-duas-versoes-RCc.png)

Após aberto o ambiente, clicar em SQL Server Network Configuration e clicar sobre o nome do client do banco em que está a tabela que desejamos acessar - geralmente é o MSSQLSERVER, mas pode ter outro nome.

![](https://cdn.elev.io/file/uploads/5G0ie0odcvxxzlQJCL8hk63Tz97zk9dh4tLJhVkC1lk/cfFrVi17WfKnsKzmgXiHMGIMNDso-o1uJE2frCwJtbQ/doc3-Qgk.png)

Os campos TCP/IP e VIA devem estar com o status **Enabled**. Para isso, devemos dar dois cliques (ou clicar com o botão direito) sobre essas opções e mudar o status **Enabled** de **No** para **Yes**.

![](https://cdn.elev.io/file/uploads/5G0ie0odcvxxzlQJCL8hk63Tz97zk9dh4tLJhVkC1lk/Sbr2dwTQvHfJKsEtw__Sj1QP0jctCCMW6d1L4LceK5Q/doc4-9Do.png)

Em seguida, na janela **Propriedades TCP/IP**, devemos clicar na aba IP Addresses, mover a barra de rolagem até ao final e definir em **IPAII**, no campo **TCP Port** a porta em que o banco está acessível (geralmente é a 1433):

![](https://cdn.elev.io/file/uploads/5G0ie0odcvxxzlQJCL8hk63Tz97zk9dh4tLJhVkC1lk/AfFiDnbltWSCGpTfd9m8k_CuoqFrYRpWrk_sTufQFQM/doc5-3pI.png)

Edições como essa exigem que o banco seja reiniciado pra que as alterações sejam aplicadas. Para isso, devemos abrir a aba **SQL Server Services** e identificar o serviço do banco de dados. No exemplo da imagem abaixo é o MSSQLSERVER, mas pode ter outro nome.

![](https://cdn.elev.io/file/uploads/5G0ie0odcvxxzlQJCL8hk63Tz97zk9dh4tLJhVkC1lk/Z6Ay92K7CB_iLbfVArwQZWpvleQtxW_aTm6uZUDt5uM/doc6-aWQ.png)

E, então, clicar com o botão direito sobre o serviço e clicar em reiniciar:

![](https://cdn.elev.io/file/uploads/5G0ie0odcvxxzlQJCL8hk63Tz97zk9dh4tLJhVkC1lk/t8_yBeMrrcaIcNssVHftSCKazu4zbcDoZQwAPG7Alqk/doc7-R0Y.png)

Após esses procedimentos, o Integrador Indeva deve ser reiniciado, e a conexão deverá funcionar normalmente. Caso ainda haja recusa na conexão, é preciso averiguar se existem outras opções no campo SQL Server Network Configuration para o caso de a configuração ter sido feita no serviço errado. É importante também testar se em alguma das opções do campo **SQL Native Client 10.0** Configuration (não sendo necessariamente a versão 10.0) a sub-opção **Via** está ativa (**Enabled**).

![](https://cdn.elev.io/file/uploads/5G0ie0odcvxxzlQJCL8hk63Tz97zk9dh4tLJhVkC1lk/9ZNS6_j3_Fx3R7-6XkqoQUsYqJ9DUXqx4PAEEs3WrN4/doc7%20(1)-ZPw.png)