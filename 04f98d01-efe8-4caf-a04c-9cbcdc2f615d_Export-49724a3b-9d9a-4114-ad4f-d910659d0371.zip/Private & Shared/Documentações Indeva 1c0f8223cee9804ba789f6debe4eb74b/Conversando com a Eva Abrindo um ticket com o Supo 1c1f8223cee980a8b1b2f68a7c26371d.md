# Conversando com a Eva/ Abrindo um ticket com o Suporte Indeva

O time Indeva conta com o apoio da inteligência artificial Eva para resolução de dúvidas simples.

Para auxiliar na comunicação, o artigo apresenta algumas imagens demonstrando como se comunicar com a nossa inteligência artificial.

Primeiramente, clique na opção "Atendimento" no menu da plataforma Indeva:

![](https://cdn.elev.io/file/uploads/5G0ie0odcvxxzlQJCL8hk63Tz97zk9dh4tLJhVkC1lk/LOjOoqalAFDJGeF1KK-Ct2q2Xad6131weJOd-EnO_Lk/Screenshot_3-7Vs.png)

De acordo com a assistência da Eva, você selecionará o respectivo time que precisa entrar em contato:

![](https://cdn.elev.io/file/uploads/5G0ie0odcvxxzlQJCL8hk63Tz97zk9dh4tLJhVkC1lk/CjSVfJ0y9H1ZU6QajIvyzTeWIGtR8w9eWcVFk713NvM/1690488614868-jFI.png)

> O fluxo de atendimento sinaliza qual ação precisa ser feita. Sendo ela escrita ou pela seleção de opções.
> 

No caso do suporte, você precisará escolher que tipo de cenário é o seu. Sendo entre eles: dúvidas, solicitações de uma configuração feita pelo Suporte Indeva ou a ocorrência de um erro inesperado:

- Para **dúvidas** como: "cadastro de vendedor; edição de metas; tablet offline, etc".
- Para **solicitações** como: "token do tablet; criação/inativação de usuário; troca de integração, etc".
- Para **erros inesperados** como: "alterou as datas dos vendedores e o sistema não recalcula a meta".

Após a seleção do seu cenário, você precisará definir o **assunto da sua solicitação** e o **ambiente** (web, aplicativo ou ambos) em que está ocorrendo a sua demanda.

![](https://cdn.elev.io/file/uploads/5G0ie0odcvxxzlQJCL8hk63Tz97zk9dh4tLJhVkC1lk/AMEJC9_l1lDWSIkQPOIOumQSkeC0LW8w0l5SLjFHw4U/1690488657089-AqI.png)

> Siga atentamente as orientações que a nossa inteligência artificial está pedindo.
> 

Nossa inteligência artificial tentará reconhecer a sua necessidade e lhe passar as orientações que necessita.

![](https://cdn.elev.io/file/uploads/5G0ie0odcvxxzlQJCL8hk63Tz97zk9dh4tLJhVkC1lk/kbkT4Me7RxLuRdGxUDQsi5sMBd9qdRWO0G7K1dseNTc/1690488733203-0Uk.png)

Ao final do que foi orientado, a Eva perguntará se conseguiu te ajudar.

![](https://cdn.elev.io/file/uploads/5G0ie0odcvxxzlQJCL8hk63Tz97zk9dh4tLJhVkC1lk/PD5FRP44OR7yt9KvVS6Vb1QE0b3yb1JAKHZPDa1F6Sk/imagem_eva_2-3sk.png)

Caso diga que ela não conseguiu te ajudar, a Eva pedirá algumas informações para que nós do time do Suporte possamos receber as mesmas e assim, você abrir um chamado efetivamente conosco.

> Não é recomendado abrir mais de um chamado sobre o mesmo assunto.
> 

![](https://cdn.elev.io/file/uploads/5G0ie0odcvxxzlQJCL8hk63Tz97zk9dh4tLJhVkC1lk/Hoac1iGpQO-FBugIfXTzeuZxnmBqaehQhgbNGx9EO9c/1690488804587-ko0.png)

> Lembrando que nosso retorno é via email e o chat com nossa inteligência artificial não aceita imagens como retorno.
> 

Ao final de tudo o que foi pedido, a Eva confirmará a abertura de chamado conosco fornecendo a confirmação e o número da sua solicitação.

![](https://cdn.elev.io/file/uploads/5G0ie0odcvxxzlQJCL8hk63Tz97zk9dh4tLJhVkC1lk/4Lw8Fr3NqiWVDZqy0rJOUVPLU8-9WkkC0aLeGQioKPQ/1690488998734-KBw.png)

> Lembrando que a abertura do chamado só é
> 
> 
> **confirmada com o envio do ID**
> 

Caso você verifique que recebeu a nossa primeira mensagem de falta de interação, não se preocupe! Pode continuar a interação com o chat a partir do que foi pedido anteriormente à mensagem.

![](https://cdn.elev.io/file/uploads/5G0ie0odcvxxzlQJCL8hk63Tz97zk9dh4tLJhVkC1lk/fAivXmpVcD9Og7ek-uOu0HnlDkpkuhDGHvPgR7hj194/1690920744950-KDI.png)

Atenção, caso a Eva sinalize uma segunda mensagem de falta de interação, o atendimento será reiniciado automaticamente e seu cenário será tratado como uma nova dúvida.

![](https://cdn.elev.io/file/uploads/5G0ie0odcvxxzlQJCL8hk63Tz97zk9dh4tLJhVkC1lk/UhRDsV7CPi8s0vVz6XY6d5fbbi81WSdYST6RCVvNpwI/1690920779347-hN4.png)

Você pode conferir o seu Ambiente de Chamados a partir do link enviado no Chat. Também poderá acessar o mesmo ambiente clicando em seu nome no canto superior direito da tela e indo em “Meus chamados”.

![](https://cdn.elev.io/file/uploads/5G0ie0odcvxxzlQJCL8hk63Tz97zk9dh4tLJhVkC1lk/kgA-a6dsrs4iC0UTyKCMyzpmYxMjsX6R6I3aOYsNyns/1690489214121-STg.png)

Nesse ambiente você pode nos enviar as evidências que julgar necessárias como fotos e vídeos.

![](https://cdn.elev.io/file/uploads/5G0ie0odcvxxzlQJCL8hk63Tz97zk9dh4tLJhVkC1lk/nuAKW9yuU2B_Y5-ItrqIhOmgQKHES7CVCH4YPbrQaTM/1690489304065-rU8.png)

> Importante
>