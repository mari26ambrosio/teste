# Passo 2 - Conferindo as respostas

Siga os passos abaixo para conferir as respostas do Formulário:

Na Indeva, clique em **Formulários** e selecione o formulário que deseja conferir, na tela seguinte a plataforma vai apresentar para quantas lojas foram enviados, quantos responderam e quantos ainda estão pendentes. É possível visualizar as respostas loja a loja, clicando em cada uma:

![](https://cdn.elev.io/file/uploads/vvJa8Eygp4CZPDf4NGbPAIydeLJytLeTCol2pMkU-no/i0xEplmQpjOC2eZ_eb8EzCKEuZDKSezvBb7H3T-fVRc/1597340523528-7Bo.png)

Na lateral direita a plataforma apresenta um resumo dos principais indicadores da loja, se o gerente está realizando o feedback, TM, PA Conversão e Usabilidade, assim facilita o gestor a ter as principais informações na tela, não sendo necessário buscar os dados em outro local.

A plataforma também faz um comparativo com cada indicador, referente ao mês/período anterior, sendo o quanto teve de diferença, para mais ou menos, e o percentual de variação, se foi positivo ou negativo, tendo facilidade na visualização nas cores entre azul (positivo) e vermelho (negativo).

O  gestor consegue comentar a resposta, no botão **"Comentar"**, podendo com isso passar orientações para o gerente/VR. Nessa opção de comentário é possível adicionar arquivos que ficam anexados ao comentário.