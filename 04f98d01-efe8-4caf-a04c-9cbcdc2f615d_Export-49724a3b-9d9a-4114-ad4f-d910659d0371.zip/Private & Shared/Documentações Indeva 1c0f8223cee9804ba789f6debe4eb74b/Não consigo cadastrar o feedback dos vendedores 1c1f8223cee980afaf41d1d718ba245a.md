# Não consigo cadastrar o feedback dos vendedores

A função de feedback tem como princípio de utilizar o **período da meta** para que você possa ter base em números e dados para *elogiar* ou *orientar* a performance do vendedor.

> Ensinamos a cadastrar o feedback neste passo a passo aqui: 🔎 [Registrar feedback para vendedores](Registrar%20o%20feedback%20para%20vendedores%201c1f8223cee98077afbef196b95a490c.md)
> 

Se você não está conseguindo cadastrar o feedback, isso pode ocorrer nas duas situações abaixo:

1) Quando tentamos cadastrar cadastrar o feedback de um **período que ainda está em andamento**;

2) Quanto tentamos cadastrar o feedback de um **período anterior a um período que já se encerrou**.

O cadastro de feedback está vinculado ao final de cada período configurado na meta. Então, **o feedback de vendedores é sempre referente ao período imediatamente anterior.**

> 💡Exemplo: A meta de uma loja é divida em 3 períodos. O feedback de vendedores do 1º período só pode ser preenchido durante o período seguinte, ou seja, durante o 2º período. Quando o 3º período começar, o feedback do 2º período ficará disponível para preenchimento, mas o feedback do 1º período ficará indisponível por ser muito antigo.
>