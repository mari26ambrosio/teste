# Qual a diferença entre Vendedor Responsável e Gerente?

Os dois perfis têm acesso ao ambiente web para acompanhar o os indicadores e relatórios da loja.

A única diferença entre os perfis é que o **Vendedor responsável aparece na lista da Vez** **e participa também da meta.**

Já o Gerente tem apenas acesso ao Web.

|  | Ambiente web | Lista da vez |
| --- | --- | --- |
| Vendedor responsável | ✅ | ✅ |
| Gerente |  | ✅ |

> 💡 Confira aqui para saber como realizar o cadastro de cada um dos perfis:
> 
> - [**Como cadastrar um Vendedor Responsável**](Vendedor%20responsa%CC%81vel%20(VR)%201c0f8223cee980669be6d25e5900e443.md);
> - [**Como cadastrar um Gerente**](Cadastro%20de%20gerente%201c0f8223cee9804792bad520d9592384.md).