# Aplicativos Indeva

Ao pesquisar na **Loja de aplicativos** do seu dispositivo a Indeva, será possível encontrar 3 aplicativos. São eles:

![](https://cdn.elev.io/file/uploads/5G0ie0odcvxxzlQJCL8hk63Tz97zk9dh4tLJhVkC1lk/wZyYbr2nONNchofzWZwzLMg2gnhldmsOwFxzbq17tmo/1680015536904-kKw.png)

**👉 App Indeva:**

Esse é o app de acesso gerencial da Loja. Nele está centralizado o resultado da loja, relatórios e Visão geral da loja. Atualmente ele só está disponível para dispositivos IOS.

**👉 App Indeva - Lista da vez:**

> Esse é o app para a instalação no Tablet da loja é compatível com o android igual ou inferior a versão 11.
> 

Esse é o app para o uso dos vendedores. Nele terá a gestão da Lista da vez e o vendedor poderá acessar sua meta e rankings.

**👉 VTEX Sales App:**

> Esse é o app para a instalação no Tablet da loja é compatível com o android superior ou igual a versão 12.
> 

Esse app é para os aparelhos que estejam com o Android com a versão igual ou superior ao 12.