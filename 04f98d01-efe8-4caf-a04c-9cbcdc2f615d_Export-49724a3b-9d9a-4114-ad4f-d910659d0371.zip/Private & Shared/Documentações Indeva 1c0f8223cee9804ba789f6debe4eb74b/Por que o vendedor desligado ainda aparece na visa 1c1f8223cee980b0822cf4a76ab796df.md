# Por que o vendedor desligado ainda aparece na visão geral?

A página de Visão Geral reúne os dados acumulados do seu ciclo mensal vigente, considerando os dias já finalizados. Ou seja, **a Visão Geral mostra a participação dos vendedores desde o primeiro dia da meta vigente até o dia anterior ao atual.**

Se um vendedor que já foi desligado ainda está aparecendo na Visão Geral, isso ocorre porque ele teve participação no atual ciclo da meta da loja.