# Por que meu aplicativo de Lista da Vez não abre no tablet?

Na maioria das vezes que o aplicativo não abre, o motivo é que o **modo de segurança do tablet foi ativado**. Com esse modo ativado, somente aplicativos do sistema (que já vem instalados em seu aparelho) irão funcionar. Os aplicativos baixados não funcionam e ficam inativos, o que impede a abertura da Lista da Vez.

Dependendo do modelo do seu tablet, existem 3 maneiras diferentes de sair do Modo de Segurança, e todas elas exigem que o aparelho seja reiniciado completamente.

A) Segure o botão volume para baixo e o botão Power (botão de liga/desliga) por pelo menos 5 segundos para **forçar o dispositivo a reiniciar**.

**OU**

B) Pressione o botão Power do lado direito e toque na opção **Reiniciar** que aparecerá na tela.

**OU**

C) Deslize para baixo da parte superior da tela para acessar o Painel de Notificação. Selecione a notificação "*O modo de segurança está ligado*" e toque em "***Desativar no prompt**"* **para** **reiniciar o dispositivo**.

> Caso o app solicite o Token, consulte essa informação com o time de atendimento através da Eva.
>