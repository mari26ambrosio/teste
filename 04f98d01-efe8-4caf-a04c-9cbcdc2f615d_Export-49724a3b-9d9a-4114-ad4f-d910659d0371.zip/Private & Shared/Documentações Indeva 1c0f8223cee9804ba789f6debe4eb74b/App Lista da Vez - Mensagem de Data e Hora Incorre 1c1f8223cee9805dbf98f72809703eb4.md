# App Lista da Vez - Mensagem de Data e Hora Incorreta

Alguns tablets estão programados para a troca do horário de verão. Você deve seguir os passos abaixo **na seguinte ordem**:

> 1 - Vá em Configurações e selecione Data e Hora﻿2 - Escolha em Selecionar Fuso horário selecione a opção "Horário da Argentina (Buenos Aires)"﻿3 - Você precisa ajustar a hora corretamente em "Definir hora"
> 

Após realizar esses passos será necessário seguir com o procedimento:

> 4 - Voltar em Configurações e clicar em Gerenciador de aplicativos﻿5 - Selecionar o app Indeva -Lista da Vez﻿6 - Clicar em Forçar parada
> 

> Segue um vídeo caso tenha dúvidas: https://youtu.be/4v-Ny0Wq9OA
>