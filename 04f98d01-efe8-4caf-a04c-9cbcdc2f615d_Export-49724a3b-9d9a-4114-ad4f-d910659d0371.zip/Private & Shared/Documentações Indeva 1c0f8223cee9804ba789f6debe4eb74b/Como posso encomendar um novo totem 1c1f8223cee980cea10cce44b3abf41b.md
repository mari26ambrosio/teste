# Como posso encomendar um novo totem?

Caso você queira adquirir um novo totem para o seu tablet, você encontra todas as informações necessárias neste artigo:🔎 [**Equipamento & Totem**](Equipamento%20&%20Totem%201c1f8223cee9800b9f5ff45cf2cdaf26.md)

> ⚠️ A Indeva só tem os direitos e responsabilidade sobre os aplicativos Indeva - Lista da Vez, Indeva e inStore. Para troca ou manutenção do equipamento, sugerimos que procure um técnico autorizado ou a loja onde o aparelho foi comprado.
>