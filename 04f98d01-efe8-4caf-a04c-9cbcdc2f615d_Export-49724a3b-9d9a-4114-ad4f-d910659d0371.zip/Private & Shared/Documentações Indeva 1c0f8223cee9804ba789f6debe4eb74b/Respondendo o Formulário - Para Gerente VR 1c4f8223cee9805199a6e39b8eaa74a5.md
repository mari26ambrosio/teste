# Respondendo o Formulário - Para Gerente/VR

Confira como **você gerente/VR**  vai responder o Formulário:

No menu lateral esquerdo clique na opção **"Formulários"**, se você já tiver com um formulário pendente de resposta a plataforma vai indicar com uma notificação, assim você vai saber quando for disponibilizado um novo para resposta.

![](https://cdn.elev.io/file/uploads/vvJa8Eygp4CZPDf4NGbPAIydeLJytLeTCol2pMkU-no/LCVkAzoqSPAiQjUI3DYD0rE383N7LNMzqm6AgTRzRVk/1597241776882-d9M.png)

Clique no formulário a ser respondido e na tela seguinte as perguntas serão apresentadas junto com os principais indicadores da loja. Para ajudar na análise são mostrados os dados como Feedback, Ticket Médio, Peças por Atendimento, Conversão e Usabilidade.

![](https://cdn.elev.io/file/uploads/vvJa8Eygp4CZPDf4NGbPAIydeLJytLeTCol2pMkU-no/aJrkqv6FvPUDGfu9rganas1sA42aiZGousdYMuktVlw/1597241939686-q0o.png)

Para facilitar na comunicação e envio de informações, no campo de resposta há um ícone para adicionar arquivos, que pode ser um levantamento, uma foto de vitrine, que poderá ser enviado para o gestor conferir.

Ao concluir as respostas clique em **"Enviar respostas"**, para finalizar o preenchimento e registrar que o formulário foi respondido. Bem simples né? ✨

Agora fique atento ao prazo de preenchimento indicado pelo seu gestor, pois após expirar esse prazo não é possível mais enviar respostas. Assim seu formulário vai constar como atrasado! 😕

Você pode conferir o prazo para resposta na tela principal dos **Formulários**, na coluna **"Prazo"**!

😉 **Dica -** Esse é o momento de apresentar ao seu gestor as ações que estão sendo colocadas em prática na loja para o desenvolvimento do resultado seu e do seu time, então capricha no envio das respostas, para que fique claro e objetivo!