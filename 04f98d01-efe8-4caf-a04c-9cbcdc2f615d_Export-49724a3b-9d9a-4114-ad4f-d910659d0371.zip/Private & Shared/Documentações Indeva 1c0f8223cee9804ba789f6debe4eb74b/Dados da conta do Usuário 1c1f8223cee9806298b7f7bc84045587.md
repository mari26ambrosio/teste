# Dados da conta do Usuário

![](https://cdn.elev.io/file/uploads/QBzHaXAsXxOVU9cJt8qy4K7_fCUmprAgEkSOPIaQEPs/nVBUVt56hf3snVu7PJsJVAOUBc0_dKAca8puijTgUa4/question-iko.png)

Para alterar as informações de cadastro da sua conta de usuário (**senha e foto**) coloque o mouse em cima da **foto do usuário**, no topo da tela, logo acima da lista dos vendedores, clique em “**Editar perfil**” e faça as alterações. Para salvar, clique em “**Atualizar**”.

> ⚠️ Importante:
> 
> 
> **Gerentes e Vendedores Responsáveis (VR)**
> 
> [**Desligar o Gerente**](Desligar%20gerente%201c0f8223cee98008aa43eae75e0f88e9.md)
> 
> [**Cadastrar Gerente**](Cadastro%20de%20gerente%201c0f8223cee9804792bad520d9592384.md)
> 

![](https://cdn.elev.io/file/uploads/PaTSwalD0CD1qzKrTIxoPy5YohxXp70Y2-RFBqKo7-Y/q_YaqewWIaT3z7QzkHlXtFEqufC2gciLbR36jQEcJ4w/Snap%202019-05-17%20at%2016.05.57-LAw.png)

![](https://cdn.elev.io/file/uploads/PaTSwalD0CD1qzKrTIxoPy5YohxXp70Y2-RFBqKo7-Y/yMePuvsk_txGubrkM2SRluUciVvnzhO68qi6VHOT9z0/Snap%202019-05-17%20at%2016.02.35-Zlk.png)