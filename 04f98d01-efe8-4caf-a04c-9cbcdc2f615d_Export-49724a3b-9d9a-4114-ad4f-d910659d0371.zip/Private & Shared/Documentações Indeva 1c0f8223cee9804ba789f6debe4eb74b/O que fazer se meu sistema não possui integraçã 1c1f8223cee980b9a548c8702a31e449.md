# O que fazer se meu sistema não possui integração automática com a Indeva?

O lançamento manual é uma alternativa simples para quando o sistema de vendas não possui integração com a Indeva. Através da validação manual, a equipe consegue atualizar as vendas e acompanhar a meta de forma eficaz.

Caso o seu sistema de vendas não possua integração automática com a Indeva, é preciso inserir manualmente na plataforma os valores de vendas. Aprenda mais sobre isso aqui: **👉 [Validação manual](Validac%CC%A7a%CC%83o%20manual%201c0f8223cee9805aa4adee5d05ba5945.md)**