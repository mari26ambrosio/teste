# PASSO 1 - Escolha uma loja

A Indeva permite que você cadastre metas para todas as lojas da sua rede que estejam registradas na plataforma.

Logo, o primeiro passo é escolher uma loja para a qual você deseja criar uma meta.

Desse modo, siga as instruções:

1. Acesse o **Admin da Indeva**.
2. Do lado esquerdo da tela, clique na **seção** **“Cadastros”**.
3. Em seguida, clique na **opção “Metas”**.
4. Clique no **botão “Cadastrar”**.
5. No **campo “Selecione a loja”**, clique no **seletor**.
6. Em seguida, clique na **loja desejada**.

Você também pode procurar pelo nome de uma loja específica na barra de busca dentro do próprio campo “Selecione a loja”.

![](https://cdn.elev.io/file/uploads/vvJa8Eygp4CZPDf4NGbPAIydeLJytLeTCol2pMkU-no/OJyXeIqzc2C9U97eWKGgS3R28B8z6HncnkC3X2sLwr8/Indeva%201-HpU.PNG)

Depois disso, o sistema encaminhará você automaticamente para a próxima etapa do cadastro. 😉