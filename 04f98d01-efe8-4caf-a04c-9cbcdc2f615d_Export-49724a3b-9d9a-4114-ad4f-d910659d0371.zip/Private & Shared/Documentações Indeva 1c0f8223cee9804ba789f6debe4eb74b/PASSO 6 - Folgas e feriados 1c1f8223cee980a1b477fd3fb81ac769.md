# PASSO 6 - Folgas e feriados

O ciclo de uma meta considera os dias úteis de um período para calcular os valores de cada período.

Consequentemente, você precisa especificar quais dias dentro daquele ciclo não se encaixam na definição de dia útil, como feriados ou folgas.

A seguir, iremos exemplificar o passo a passo com uma regra aplicada a uma sexta-feira. Porém, você pode realizar essa configuração em qualquer dia da semana.

Confira:

1. No calendário, **clique no dia em que você deseja editar** a disponibilidade.
2. No **campo “Toda equipe da loja”**, clique no **seletor**.
3. Em seguida, selecione **um dos vendedores** para sinalizar que a **folga é apenas para aquele funcionário** ou a opção **“Toda equipe da loja”** para destacar que **o time inteiro não trabalhará** naquele dia.
4. No **campo “Dia útil”**, clique no **seletor**.
5. Selecione a **opção “Folga sem meta”**.
6. Se você quiser aplicar a regra **apenas naquele dia específico**, clique no **botão “Aplicar em 5 de agosto”**. Caso contrário, clique no **botão “Aplicar em todas as sextas-feiras”** para aplicar a regra **em todas as sextas-feiras do período**da meta.Abaixo um exemplo de como cadastrar a folga no calendário:
    
    ![](https://cdn.elev.io/file/uploads/tBgen6l2bR68tnG4jliwz2r3Y7l43THZ1FPLchAS11w/wugZQixh8TENDGvYC1rv-CbOXVi-e8hz-pz6sw04Xqo/Meta%20v2%20-%20Cadastrar%20folga-u-Q.gif)
    
7. Clique no **botão “Próximo”**.