# Como cadastro um colaborador?

O caminho para desligar o colaborador depende se ele é vendedor, gerente ou usuário (supervisor, administrador, franqueado). Clique no caso correspondente para ser direcionado ao passo a passo:

[**1) Para cadastrar um vendedor**](Cadastro%20de%20vendedor%201c0f8223cee9804f821dc1fff55b500a.md)

[**2) Para cadastrar um gerente**](Cadastro%20de%20gerente%201c0f8223cee9804792bad520d9592384.md)

[**3) Para cadastrar um usuário (supervisor, administrador, franqueado)**](Cadastrar%20um%20novo%20usua%CC%81rio%20(franqueado,%20supervisor%201c0f8223cee98088b341cea602a331e4.md)

> Encontrou alguma dificuldade no cadastro? Você pode encontrar a solução aqui:
🔎[Não consigo cadastrar meus colaboradores](Na%CC%83o%20consigo%20cadastrar%20meus%20colaboradores%201c0f8223cee98080b6f9c22c93dcdf90.md)
>