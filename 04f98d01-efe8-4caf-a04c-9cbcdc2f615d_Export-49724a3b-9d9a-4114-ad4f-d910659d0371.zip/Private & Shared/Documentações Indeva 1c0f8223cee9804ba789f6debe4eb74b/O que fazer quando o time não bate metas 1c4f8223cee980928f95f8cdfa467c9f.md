# O que fazer quando o time não bate metas

Neste **Webinar** conversamos sobre **metas e desempenho de equipe**. Como mudar a estratégia da loja para aumentar o resultado de vendas do seu time!

Assista e aprenda como potencializar a performance dos seus vendedores.

Acesse por esse link:

[**https://www.youtube.com/watch?v=egvWf0iBoJc**](https://www.youtube.com/watch?v=egvWf0iBoJc)