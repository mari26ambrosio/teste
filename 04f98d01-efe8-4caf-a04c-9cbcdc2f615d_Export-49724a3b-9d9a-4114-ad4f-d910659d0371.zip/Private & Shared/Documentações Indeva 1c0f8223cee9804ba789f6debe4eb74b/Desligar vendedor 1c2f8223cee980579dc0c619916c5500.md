# Desligar vendedor

Para desligar um vendedor ativo da loja é simples!

> Entre no Menu (na lateral esquerda) > Cadastro > Vendedores ”.
> 

Clique em "**Ações**", "**Férias ou** **Inativar**". Conforme abaixo:

![](https://cdn.elev.io/file/uploads/QBzHaXAsXxOVU9cJt8qy4K7_fCUmprAgEkSOPIaQEPs/s1-x7J7t7PqsiVfcy3-oQYARqrU_genbT4xqjmqQnF8/Snap%202018-01-19%20at%2011.03.08-Oqk.png)

Clique em "**Desligamento**", selecione o "**motivo do desligamento**" e preencha na "**data do desligamento" o último dia trabalhado pelo vendedor**.

![](https://cdn.elev.io/file/uploads/QBzHaXAsXxOVU9cJt8qy4K7_fCUmprAgEkSOPIaQEPs/s-OJQIuyWuet7chvXH19m5GzG2O2xaUF27YnRWRcZEg/Snap%202018-01-19%20at%2011.06.26-404.png)

**😉 DICA -** Fique atento na hora de preencher a data de desligamento do vendedor, não é possível editá-la depois!