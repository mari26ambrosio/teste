# Por que minha loja não aparece no Web Indeva?

Tenho acesso de Supervisor/Franqueado/Admin:

Somente lojas que foram **ativadas, com meta cadastrada** e **adimplentes** aparecem na página inicial e nos relatórios.

> ⚠️Importante: não é porque o tablet foi habilitado que a loja está automaticamente ativa, são duas coisas diferentes!
> 

Caso sua loja esteja ativa mas não esteja aparecendo, verifique se já foi cadastrada uma meta para o ciclo atual e se todas as mensalidades da Indeva foram pagas dentro do prazo de vencimento. Em caso de não pagamento do boleto, a loja poderá ser bloqueada após 15 dias do seu vencimento.

Se a sua loja ainda estiver em período de implantação, não se preocupe, você pode cadastrar vendedores e gerentes mesmo assim.

> Atenção: caso você seja o Gerente ou VR de +1 loja e tenha perdido acesso de uma delas, significa que o período de acesso tenha terminado para ela.
> 
> 
> Para retornar a ter o acesso, é preciso conferir com seu superior para realizar novamente seu acesso na loja.
>