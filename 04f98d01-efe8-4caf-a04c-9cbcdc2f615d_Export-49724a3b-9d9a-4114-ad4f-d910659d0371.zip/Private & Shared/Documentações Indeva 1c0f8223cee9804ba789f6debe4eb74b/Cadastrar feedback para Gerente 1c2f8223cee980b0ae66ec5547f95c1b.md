# Cadastrar feedback para Gerente

👉 **Como fazer?**

![](https://cdn.elev.io/file/uploads/QBzHaXAsXxOVU9cJt8qy4K7_fCUmprAgEkSOPIaQEPs/wGZOpfF0hx8RBg_--sCVYviSKc4Q5kTWMHg3p5zIl8M/1542977356287-mfY.png)

O *feedback* de gerente poderá ser incluído na Indeva a qualquer momento. Para inserir novo

*feedback* clique em **Feedback > Gerentes > Cadastrar Feedback para Gerente**.

Selecione o gerente e o período de avaliação e marque “realizar feedback”.

Na tela seguinte o sistema apresenta os resultados do período marcado, e a partir dessas informações você pode **analisar e posicionar o gerente quanto ao desempenho da loja**.

**Dica:** Aproveite a simulação dos indicadores para engajar seus gerentes com possibilidade de maiores números de PA, Taxa de Conversão e Ticket Médio.

Para concluir clique em **“Realizar Feedback”** para salvar as informações.

**Atenção:** *Confira as informações incluídas, pois quando salvar a tela não é possível editar o feedback, fique atento!*

👉Você pode acompanhar o comentário do gerente ao feedback, selecione o feedback e marque “**visualizar**”, em comentários você confere o retorno do gerente e também inclui mais tópicos se precisar !