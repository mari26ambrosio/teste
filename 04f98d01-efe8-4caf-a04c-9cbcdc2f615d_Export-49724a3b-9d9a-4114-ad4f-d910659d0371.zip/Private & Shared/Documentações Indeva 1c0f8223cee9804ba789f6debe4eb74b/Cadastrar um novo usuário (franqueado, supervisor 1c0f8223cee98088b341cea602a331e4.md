# Cadastrar um novo usuário (franqueado, supervisor e equivalentes)

Na Indeva, **usuários** são todos aqueles que utilizam a plataforma mas não são gerentes nem vendedores. É o caso dos **franqueados, supervisores, consultores, entre outros equivalentes.**

Usuários podem ter acesso a várias (ou todas) as lojas de um(a) franqueado(a) ou de uma rede dependendo do que for acordado com a gestão.

Se você deseja cadastrar um novo usuário, você só precisa abrir um chamado informando os dados abaixo:

**👉 Nome;**

**👉 E-mail;**

**👉 Função;**

**👉 Lojas a que o usuário terá acesso.**

Depois disso, é só aguardar o retorno do nosso time de suporte! 😉

> ⚠️Importante: o pedido de cadastro deve ser feito por um usuário com acesso superior.
> 
> 
> Exemplo: para criar um acesso de supervisor, é necessário autorização do franqueado ou do administrador da conta.
>