# PASSO 8 - Formato de metas dos vendedores

Ao cadastrar uma meta, seja ela **por mês** ou **por período**, você pode ter mais controle sobre as metas de cada vendedor.

Depois da etapa de distribuição de pesos da meta, você verá uma página com três opções de distribuição de meta entre os vendedores:

- **Pesos proporcionais:** dividem a meta da loja em pesos iguais entre os vendedores, sempre respeitando o valor da meta da loja. O valor da meta de cada vendedor pode sofrer alteração se posteriormente você lançar dias sem meta para ele(a), registrar uma ausência temporária ou registrar demissão no cadastro do vendedor. Neste caso, a meta que seria desse vendedor será distribuída entre os demais vendedores.
- **Pesos personalizados:** permitem que você customize a distribuição de peso entre os vendedores, sempre respeitando o valor da meta da loja. O valor da meta de cada vendedor pode sofrer alteração se posteriormente você lançar dias sem meta para ele(a), registrar uma ausência temporária ou registrar demissão no cadastro do vendedor. Neste caso, a meta que seria desse vendedor será distribuída entre os demais vendedores.
- **Metas independentes:** permitem separar a meta da loja da meta dos vendedores. Com isso, a meta dos vendedores pode ultrapassar a meta da loja. Neste modelo, a meta dos vendedores é fixa, ou seja, o vendedor, independente de alterações na sua escala de dias de trabalho, sempre tem o mesmo valor de meta.

Para realizar essa etapa do cadastro, clique na opção correspondente ao modelo de distribuição de metas que você deseja usar.

Se você optar pela distribuição em **Pesos proporcionais**, essa configuração será realizada automaticamente pela plataforma.

Se optar por **Pesos personalizados** ou **Metas independentes**, você será conduzido(a) para uma página de edição onde poderá atribuir os valores das metas para cada vendedor. Continue a leitura para mais informações sobre essa edição.

## **Pesos personalizados - Qual o valor de meta de cada vendedor?**

Nesta página, você pode editar os valores e percentuais das metas de cada vendedor. O total das metas individuais **deve ser igual** à meta da loja.

Quando estiver pronto(a), clique em **Próximo**.

## **Metas independentes - Qual o valor de meta de cada vendedor?**

Nesta página, você pode editar os valores e percentuais das metas de cada vendedor de forma independente, ou seja, o total das metas individuais **pode** ser diferente da meta da loja.

Quando estiver pronto(a), clique em **Próximo**.

![](https://cdn.elev.io/file/uploads/vvJa8Eygp4CZPDf4NGbPAIydeLJytLeTCol2pMkU-no/cDQGzW_zasl-nlov8bueqiBQYDl4m2Vqibz8HpkJ81Q/image2-nlk.png)

## **Observações - metas de vendedores por período**

Confira a seguir algumas observações importantes sobre a distribuição de **metas de vendedores por período**.

Você pode apenas distribuir metas para os vendedores nos períodos **que já têm meta da loja cadastrada**.

Por exemplo: você criou três períodos e cadastrou uma meta apenas para o 1º período. Com isso, você apenas pode distribuir metas entre os vendedores para o 1º período, porque é o único período com valor de referência na plataforma.

Se você escolher usar as **metas por período**, você **não precisa cadastrar de uma só vez todas as metas de todos os períodos**. Isso permite que você distribua a meta entre vendedores a cada período. Confira o [**PASSO 5 - Valores dos períodos da meta**](PASSO%205%20-%20Valores%20dos%20peri%CC%81odos%20da%20meta%201c2f8223cee98027af2efd16107d2d20.md) para mais informações.

Quando um período chega ao fim, é importante que você cadastre a meta do período que está para começar. Para isso, acesse a meta que está em andamento conforme as instruções a seguir.

1. Clique em **Cadastros** > **Metas**.
2. Na listagem de metas, passe o cursor sobre o botão **Ações** e clique na opção **Editar**.
3. Na página de resumo da meta, ilustrada abaixo, você verá um alerta informando que está na hora de criar as metas do período que vai começar. Clique em **Editar meta da loja** e, caso necessite de ajuda, consulte o artigo [**PASSO 5 - Valores dos períodos da meta**.](PASSO%205%20-%20Valores%20dos%20peri%CC%81odos%20da%20meta%201c2f8223cee98027af2efd16107d2d20.md)

![](https://cdn.elev.io/file/uploads/vvJa8Eygp4CZPDf4NGbPAIydeLJytLeTCol2pMkU-no/GzvHRQoala5JkGOlcAFqE9r3ZQ3OvPZCzammIYM_ra4/editar-meta-Lro.png)

Após cadastrar a meta da loja para o novo período, o fluxo de cadastro seguirá para a distribuição de meta entre os vendedores.

🧐 **Fique ligado:** se você editar metas da loja de períodos já concluídos, essa alteração vai alterar os dados dos indicadores e não será possível recuperar a versão anterior da meta.

---

Se quiser editar a meta dos vendedores para esse período posteriormente, clique em **Editar metas da equipe**. Assim, você será direcionado(a) para esta etapa do cadastro, ilustrada a seguir. Confira o artigo [**PASSO 8 - Formato de metas**](PASSO%208%20-%20Formato%20de%20metas%20dos%20vendedores%201c2f8223cee9803ea099fd19b1ac59ca.md) para mais informações.

![](https://cdn.elev.io/file/uploads/vvJa8Eygp4CZPDf4NGbPAIydeLJytLeTCol2pMkU-no/fE1CP9l7-jYjA0xyuf5eoHUjuxs72-tqEwE8o90Ypio/image6-J1Y.png)