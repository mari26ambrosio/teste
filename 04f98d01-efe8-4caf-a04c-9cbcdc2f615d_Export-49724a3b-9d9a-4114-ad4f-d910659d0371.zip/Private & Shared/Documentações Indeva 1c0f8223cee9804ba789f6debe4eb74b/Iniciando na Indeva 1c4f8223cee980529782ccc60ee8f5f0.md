# Iniciando na Indeva

**Estamos animados por receber você e a sua equipe!**

A **Indeva** é o seu novo espaço de trabalho, um lugar que une as metas e resultados da sua equipe para você focar **100%** no crescimento da sua empresa.

**Opa!** Você é gestor e precisa aprender como funciona a plataforma **Indeva**? Legal! Está no lugar certo!🎉

Dê o play no vídeo🎥 e conheça como a **Indeva** pode te ajudar a potencializar os resultados de vendas🤑!

Clique nesse link aqui: [**https://youtu.be/i5mNArEeSEo**](https://youtu.be/i5mNArEeSEo)

**Treinamento de utilização da Indeva**

Nesse vídeo apresentamos as funcionalidades do sistema e de que forma você pode aproveitar ao máximo a **Indeva** para gerenciar sua loja📈!

Clique nesse link aqui: [**https://youtu.be/jQeIBT3sc8Q**](https://youtu.be/jQeIBT3sc8Q)

Lembrando que temos mais conteúdos e artigos no nosso menu Ajuda e nos links abaixo:

- Treinamento Indeva parte 1 - Lista da Vez: [**https://www.youtube.com/watch?v=9_QfWN5Z2WU**](https://www.youtube.com/watch?v=9_QfWN5Z2WU)
- Treinamento Indeva parte 2 - Retaguarda: [**https://www.youtube.com/watch?v=6Fve_4wZAaQ**](https://www.youtube.com/watch?v=6Fve_4wZAaQ)