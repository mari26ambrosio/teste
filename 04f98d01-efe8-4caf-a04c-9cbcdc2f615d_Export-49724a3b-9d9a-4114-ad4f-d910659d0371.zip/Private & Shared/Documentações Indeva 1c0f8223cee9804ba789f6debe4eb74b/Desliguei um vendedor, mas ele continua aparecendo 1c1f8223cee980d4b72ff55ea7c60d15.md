# Desliguei um vendedor, mas ele continua aparecendo na meta. O que eu faço?

Caso a meta tenha sido cadastrada antes do desligamento do vendedor, ela será mantida mesmo após a inativação.

Para contornar essa situação, **cadastre “Folga sem meta” para o vendedor em todos os dias não trabalhados**. Segue o passo a passo:

1. Abra a tela de edição da meta.
2. Clique em **Editar dias úteis e folga**.
3. Selecione no calendário o primeiro dia não trabalhado pelo vendedor.
4. No campo “Toda equipe da loja”, clique no seletor e escolha o vendedor desligado.
5. No campo “Dia útil”, clique no seletor e escolha “Folga sem meta”.
6. Repita o processo para os demais dias não trabalhados pelo vendedor naquele mês...

…e prontinho! ✨