# Desligando o Vendedor Responsável

Primeiro será preciso Finalizar o período como V.R

Para isso, no painel do V.R, em **Ações** você precisa clicar em Finalizar período como V.R.

![](https://cdn.elev.io/file/uploads/vvJa8Eygp4CZPDf4NGbPAIydeLJytLeTCol2pMkU-no/kscGZOFjpATMdCDMjspimXbX_iyvc8ii7zK-qQhnHuM/1652477320708-G5Y.png)

Em seguida informe a data de último dia como VR e clique em Finalizar

![](https://cdn.elev.io/file/uploads/vvJa8Eygp4CZPDf4NGbPAIydeLJytLeTCol2pMkU-no/3m9-Ri84YD9FPUA31o9qeQvlIzJYpboCmTNk-Tgfl-o/1652477494161-JMg.png)

> 🚨 Importante: Essa ação apenas revoga o acesso do VR e o torna como um vendedor normal da loja. Caso precise desliga-lo da loja é preciso realizar o processo de [desligar o vendedor](Desligar%20vendedor%201c2f8223cee980579dc0c619916c5500.md).
>