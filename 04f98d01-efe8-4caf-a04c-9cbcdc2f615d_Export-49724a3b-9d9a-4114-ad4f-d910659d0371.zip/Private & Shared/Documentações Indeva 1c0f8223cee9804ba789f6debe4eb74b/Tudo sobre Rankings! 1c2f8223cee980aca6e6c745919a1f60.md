# Tudo sobre Rankings!

Olha que legal: para estimular a participação de várias lojas ou vendedores em uma competição saudável, a Indeva criou o **Ranking**, que pode ser criado para um grupo de lojas ou grupo de vendedores.

![](https://cdn.elev.io/file/uploads/QBzHaXAsXxOVU9cJt8qy4K7_fCUmprAgEkSOPIaQEPs/eeoqotflvk4_6RDifVob45qnvew8BZ1WtEEH1YmA0AY/ranking-vDU.png)

**Como fazer?**

Para criar uma ranking é simples! Clique em “🏆Ranking” no menu (lateral esquerda), escolha qual tipo de Ranking (vendedores ou lojas) e clique no botão **“+Adicionar”**. Preencha os campos necessários (o **período**, as **regras**, os **participantes** e defina a **premiação**). E não esqueça de escolher uma foto legal que represente o ranking, comunicação visual é tudo! Por fim, clique em salvar!

Os vendedores podem acompanhar o ranking pelo Tablet! 😃 Essa informação fica disponível no botão "**Rankings**" na tela principal da Lista da Vez.