# Termo de Uso

Você pode consultar nosso [**Termo de Uso aqui**](https://indeva.com.br/contratos/indevabyvtex.pdf)!