# PASSO 3 - Definição do ciclo temporal da meta

Agora você ****deve definir a duração do ciclo da meta.

💡 Lembre-se: não há tempo limite para configurar o ciclo de uma meta. Você pode cadastrá-lo como preferir.

---

Para isso, siga as instruções:

1. Em **“Início da meta”**, estabeleça uma **data de início** para a meta.
2. Em **“Final da meta”**, estabeleça uma **data de término** para a meta.
3. Em **“Mês de referência”**, **selecione o mês** entre as opções indicadas.

🧐 Fique ligado: em casos que o ciclo mensal contempla dois meses diferentes, você deve definir como o mês de referência aquele que tiver mais dias dentro do ciclo da meta.

---

Assim que você selecionar o mês de referência, a plataforma o encaminhará para a próxima etapa.