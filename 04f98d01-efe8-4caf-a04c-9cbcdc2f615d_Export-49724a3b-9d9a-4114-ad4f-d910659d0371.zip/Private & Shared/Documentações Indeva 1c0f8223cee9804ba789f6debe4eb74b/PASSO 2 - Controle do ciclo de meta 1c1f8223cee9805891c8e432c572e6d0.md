# PASSO 2 - Controle do ciclo de meta

Toda meta é definida por um ciclo temporal. Por exemplo, podemos definir que a meta de uma loja seja alcançar R$120.000 em vendas ao longo de um mês - um ciclo temporal **mensal**.

Desse modo, a Indeva permite que você crie ciclos temporais para as suas metas, alinhados com as necessidades do seu negócio.

Logo, nesta etapa você deve decidir o ciclo temporal da sua meta.

Existem duas modalidades:

- **Meta por mês**: o valor total da meta será distribuído entre os dias úteis de um determinado mês. Na **meta por mês**, existe um único objetivo de meta que é o montante ao final do mês. Cada avanço na meta feito por período é contabilizado ao final do mês.
- **Meta por período**: o valor total da meta será distribuído entre os períodos que você decidir criar. Por exemplo, em um mês, é possível criar dois períodos de quinze dias. Na **meta por período**, a cada período existe um novo objetivo de meta, então dentro de cada período existe uma meta diferente. Cada uma dessas metas por período é independente, ou seja, elas não são somadas ao final do período.

Para realizar essa etapa do cadastro, clique na opção correspondente ao controle que você deseja configurar.

![](https://cdn.elev.io/file/uploads/vvJa8Eygp4CZPDf4NGbPAIydeLJytLeTCol2pMkU-no/veZuZR6SJ-kcIcsecWI3Xli5rQwZVUPlTqj6Oefcvjw/indeva%202-I7k.PNG)

Assim, o sistema irá direcioná-lo para a próxima etapa do cadastro.