# Status Validação

Após qualquer edição manual na tela de validação, a Indeva exibe **o status do último horário, dia e usuário que realizou a atualização.** Assim fica mais fácil gerenciar as edições realizadas nos valores da loja.

O novo ambiente agora apresenta novas colunas na página de validação para que possa ter fácil acesso aos dados, como: **Última atualização do Integrador**, **Última validação** e a foto do **Validador** do dia em questão.

Além disso, você acompanha por dia, a última integração daquele dia e as datas que foram validadas ou não.

![](https://cdn.elev.io/file/uploads/tBgen6l2bR68tnG4jliwz2r3Y7l43THZ1FPLchAS11w/FAMBWnX7CUuZNrbVc2C9OxpWo1d4TjQwz9cgs9KoKeo/Valida%C3%A7%C3%A3o%20-%20Status%20de%20valida%C3%A7%C3%A3o-pKs.gif)

### **Status:**

**❌** **Não validado**

São os valores que ainda não foram validados.

✔️ **Validado:**

Quando o dia é validado sem qualquer tipo de edição manual.

👍 **Validado e atualizado**

É quando um dia "validado" sofre alguma edição pelo integrador na atualização automática (comunicação entre o PDV e a Indeva).

🖐️ **Validado com edição manual**

Quando o dia é "validado" e houve edição manual.