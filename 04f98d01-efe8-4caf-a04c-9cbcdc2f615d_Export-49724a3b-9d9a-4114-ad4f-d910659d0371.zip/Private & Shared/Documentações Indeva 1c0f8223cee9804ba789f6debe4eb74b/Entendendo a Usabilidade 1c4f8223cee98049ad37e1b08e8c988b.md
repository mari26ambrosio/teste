# Entendendo a Usabilidade

A **usabilidade** é a métrica criada pela Indeva que ajuda o gerente avaliar se os registros de “sucessos” na **lista da vez** estão sendo realizados de forma correta pelos vendedores.

Nossa plataforma compreende se as marcações feitas no app **Indeva - Lista da Vez** ou o app **VTEX Sales App** estão compatíveis com as vendas do seu PDV, fazendo o cruzamento entre as **marcações de Sucesso** indicadas pelo vendedor com a **Qtd de vendas** que o vendedor tem no seu PDV/Validação, fazendo assim uma métrica percentual.

Para acompanhar a **usabilidade**, entre no menu “relatórios”, “raio x”. Acreditamos que um percentual de usabilidade aceitável é de 85%, ideal 90% e excelente 95%.

> ➕ No relatório Raio X, a
> 
> 
> **usabilidade (+)**
> 
> ➖ No relatório Raio X, a **usabilidade (-)** é quando o vendedor deixou de marcar “sucessos” na lista da vez.
> 

> ⚠️ Importante:
> 
> 
> **esse indicador não inclua o dia atual**
> 
> **integração dessas informações serem distintas**
> 
> **não instantâneas**
> 

Para concluir é importante ressaltar que a usabilidade é uma métrica exclusiva para medir o número de sucessos marcados pelos seus vendedores na **Lista da Vez - Digital.** A usabilidade não é uma métrica que mede o quanto você usa ou deixa de usar a **Indeva** **web** ou a **Lista da Vez** corretamente, ok? Cuidado para não criar confusão. 😉