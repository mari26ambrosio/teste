# Por que minhas marcações na Lista da Vez não estão subindo para a Indeva?

O app Lista da Vez só fica offline por dois motivos:

**A) Tablet sem conexão estável de wi-fi**

Nem sempre a conexão pelo Wifi é sinônimo que o aparelho está recebendo sinal de internet, confira a conexão das seguintes formas:

👉 **Navegue pela internet** - faça busca sobre qualquer dado ou informação. Exemplo: Entre no google e pesquise por Indeva.

👉 **Troque de rede** - Tente escolher outra rede Wifi, é possível fazer isso pareando com outro aparelho móvel ao rotear a conexão da sua operadora móvel.

OU

**B) Data e hora do tablet estão errados ([Confira aqui como corrigir](https://indeva.elevio.help/pt-br/articles/184))**

OU

**C) Existe um vendedor em atendimento**

O App Indeva - Lista da Vez ou VTEX Sales App só atualiza as marcações quando não há nenhum vendedor em atendimento, ou seja, todos estejam na fila de espera ou fora de expediente.