# Registrar o feedback para vendedores

![](https://cdn.elev.io/file/uploads/QBzHaXAsXxOVU9cJt8qy4K7_fCUmprAgEkSOPIaQEPs/fQ1SuvImGxqeNrRf74pyJ6mgWHROOJ4VPituD87bEbc/question-pCE.png)

Criar uma **cultura de *feedback*** é essencial para a performance das vendas. Isto porque, quando registrado e realizado com periodicidade, **os *feedbacks* criam um compromisso com os vendedores**, um eterno trabalho em progresso em busca da melhora dos indicadores de venda. Além disso, o pessoal da retaguarda consegue acompanhar o trabalho realizado pelo gerente nos

*feedbacks*.

> ⚠️ A função de feedback tem como princípio de utilizar o período da meta para que você possa ter base em números e dados para elogiar ou orientar a performance do vendedor.
> 
> 
> O cadastro de *feedback* está vinculado ao final de cada período configurado na meta, e o *feedback* de vendedores é sempre referente ao **período imediatamente anterior**.
> 
> **Exemplo**: A meta de uma loja é divida em 3 períodos. O feedback do 1º período para os vendedores só pode ser preenchido durante o período seguinte, ou seja, durante o 2º período. Quando o 3º período começar, o feedback do 2º período poderá ser preenchido, mas o feedback do 1º período ficará indisponível por ser muito antigo.
> 

👉 **Como fazer?**

É possível criar os *feedbacks* por dois caminhos: pelo menu do painel em “Feedbacks” ou na tela de perfil do vendedor.

Ao clicar em **“Realizar”**, o sistema dá uma ajudinha e traz o último *feedback* realizado. Esta ação te atualiza para criar o próximo *feedback*.

Além disso, **o sistema compara os resultados do vendedor em relação à média da loja**. Conforme selecionado na imagem abaixo:

![](https://cdn.elev.io/file/uploads/QBzHaXAsXxOVU9cJt8qy4K7_fCUmprAgEkSOPIaQEPs/ihmEF-3u8-pFnjGDS9Lnj2Zq_fIjKCYvtrOajo2aYlE/feedback-vWk.png)

😉 **DICA - Simule** o melhor resultado de acordo com o indicador. Assim fica mais fácil o vendedor visualizar o plano de ação e no que poderia ter melhorado! E **atenção:** o *feedback* deverá ser realizado ao final de cada período, ok?

> Não está conseguindo cadastrar um feedback? Dá uma olhadinha nesse artigo aqui: 🔎 [Não consigo cadastrar o feedback dos vendedores](Na%CC%83o%20consigo%20cadastrar%20o%20feedback%20dos%20vendedores%201c1f8223cee980afaf41d1d718ba245a.md)
>