# Entendendo a Usabilidade na Indeva

🎥Nesse **Webinar** mostramos como é calculada a usabilidade na **Indeva**.

Assista ao vídeo e confira as informações necessárias para que esse indicador seja bem aplicado aí na loja! 😉

Assista por esse link: [**https://youtu.be/zlgJAgQ_9Z8**](https://youtu.be/zlgJAgQ_9Z8)