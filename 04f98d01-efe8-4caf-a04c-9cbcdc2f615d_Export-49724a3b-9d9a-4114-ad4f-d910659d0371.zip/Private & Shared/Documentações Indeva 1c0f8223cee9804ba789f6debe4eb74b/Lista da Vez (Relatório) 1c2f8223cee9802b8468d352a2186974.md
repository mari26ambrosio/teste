# Lista da Vez (Relatório)

Saiba todas as movimentações que os seus vendedores registram na **Lista da Vez digital** e quanto tempo eles investem no atendimento!

Nesse relatório você pode conferir o tempo médio da loja em relação aos atendimentos, tempo total na loja e as pausas dos vendedores.

Você acessa essas informações assim:

> Entre no Menu da Indeva (na lateral esquerda) > 📄 Relatórios > Lista da Vez.
> 

![](https://cdn.elev.io/file/uploads/PaTSwalD0CD1qzKrTIxoPy5YohxXp70Y2-RFBqKo7-Y/EmopcQ2grOvi9k5U6BKXhUIcSRqBe9vEuUQlpsvViWg/Snap%202019-08-12%20at%2011.25.54-8NA.png)

**Na loja:** Mostra o ***tempo médio dos vendedores na loja*** dentro do período informado, e compara cada vendedor como está o seu tempo de acordo com o da loja.

**Por atendimento:** Mostra o ***tempo médio que os vendedores ficaram por atendimento***, dentro do período indicado no filtro e compara cada vendedor, como está o desempenho dele de acordo com o da loja.

**Em pausas:** Mostra o ***tempo médio de pausas indicadas na Lista da Vez***, dentro do período indicado no filtro e compara cada vendedor, como está o resultado dele de acordo com o da loja.

**Barra de distribuição do tempo:**

![](https://cdn.elev.io/file/uploads/PaTSwalD0CD1qzKrTIxoPy5YohxXp70Y2-RFBqKo7-Y/lf1bHGiLAZlw6X-7pgL13A_bBUpF3fn4DQ9Uezq9uco/Snap%202019-01-21%20at%2016.41.34-9Z8.png)

Aqui o sistema apresenta as divisões de tempo médio da loja e por vendedor. É possível identificar o tempo médio em atendimentos, na fila da vez e em pausas.

**Detalhes por vendedor:**

Na tela de filtro é possível escolher o vendedor para visualizar e para conferir os detalhes do vendedor, clique no nome dele e na tela seguinte irá abrir as movimentações do vendedor. Aqui você poderá navegar em dias diferentes, analisando dia a dia.

![](https://cdn.elev.io/file/uploads/PaTSwalD0CD1qzKrTIxoPy5YohxXp70Y2-RFBqKo7-Y/BLj7Yg1jK7jUy0B2aHkg8Glynt2N9jl33RFPceYWIEs/Snap%202019-01-21%20at%2016.54.42-x24.png)

Utilize o relatório da Lista da Vez para acompanhar a usabilidade da sua loja e também a gestão do tempo dos seus vendedores! 🧐