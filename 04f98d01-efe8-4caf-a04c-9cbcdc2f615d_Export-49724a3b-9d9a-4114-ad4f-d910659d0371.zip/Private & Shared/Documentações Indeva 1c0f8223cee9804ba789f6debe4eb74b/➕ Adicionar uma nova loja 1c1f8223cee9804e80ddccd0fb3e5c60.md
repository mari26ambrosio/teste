# ➕ Adicionar uma nova loja

A Indeva utiliza o modelo de assinatura SAAS e a assinatura está vinculada para cada loja.

Para adicionar uma nova loja é preciso abrir uma solicitação com o time comercial e assim realizar a proposta para  adicionar a nova loja.

> Para falar com o time comercial, recomendamos abrir a solicitação através deste link.
> 

Através do link acima, o seu contato chegará ao time responsável e será retornado assim que estiverem disponível!

> Importante: Na propriedade "Tipo de solicitação" é preciso selecionar a opção "Nova Loja" para aparecer o formulário correto.
> 
> 
> ![](https://cdn.elev.io/file/uploads/tBgen6l2bR68tnG4jliwz2r3Y7l43THZ1FPLchAS11w/h4xgF6nMbd8n4p9kyDzwkbBuoOkfxasoxZh9uPQ5-uU/1670438740678-TmI.png)
>