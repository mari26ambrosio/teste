# Eventos e Motivos

O **Eventos e Motivos** é o relatório da Indeva que te mostra as marcações realizadas na Lista da Vez!

Este relatório foi criado para agrupar todas as movimentações do aplicativo Lista da vez de uma maneira simples e prática.

Você tem a possibilidade de comparar as informações com dados do mês anterior ou ano anterior, de acordo com a data indicada no filtro.

Os números correspondem à quantidade de opções marcadas no tablet. Essas opções são somadas caso seja selecionada mais de uma opção em um atendimento.

**⚠️ Atenção -** É preciso filtrar a data início e fim antes de acessar as informações de qualquer relatório. =)