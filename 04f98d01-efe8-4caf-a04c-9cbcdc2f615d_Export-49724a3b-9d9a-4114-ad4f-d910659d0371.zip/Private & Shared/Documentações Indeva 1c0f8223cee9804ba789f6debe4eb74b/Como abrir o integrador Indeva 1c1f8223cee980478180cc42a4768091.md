# Como abrir o integrador Indeva?

O **Integrador Indeva** é uma aplicação que faz a ponte entre seu sistema de vendas e a Indeva, garantindo a atualização das informações. Quando integrador está **offline no computador principal da loja** as vendas não irão integrar na plataforma.

> Importante: Mesmo que as vendas não estejam integrando, elas estão sendo armazenadas, ou seja, a partir do momento que o integrador estiver online e funcionando, as mesmas entrarão normalmente na plataforma.
> 

Para abrir o integrador, siga o procedimento abaixo:

1- No ícone que fica na área de trabalho do computador principal da loja/servidor,

**dar um duplo clique para abrir o Integrador**.

![](https://cdn.elev.io/file/uploads/5G0ie0odcvxxzlQJCL8hk63Tz97zk9dh4tLJhVkC1lk/ViyEqlAmzkyhG6vqRQ-OmvB7iXG0x2OchtFnLNOQFEQ/abrir%20integrador%20(1)-8W8.gif)

2- ﻿Quando a aplicação estiver funcionando, ela aparecerá no menu de opções que fica no **canto inferior direito do desktop, próximo ao relógio**. Clique com o **botão direito do mouse e em "abrir integrador".**

![](https://cdn.elev.io/file/uploads/5G0ie0odcvxxzlQJCL8hk63Tz97zk9dh4tLJhVkC1lk/tQVe1SNIBExqNmgEUIrve7oicjl1IIn6S9D7QfPTHig/abrir%20integrador2-H3M.gif)

3- Ao abrir o Integrador, verifique se os indicadores de conexão estão verdes.

![](https://cdn.elev.io/file/uploads/5G0ie0odcvxxzlQJCL8hk63Tz97zk9dh4tLJhVkC1lk/oBhEuUQoS0yeBTcrvXeogCba6CuwdGaCYngn6Leplhc/1704832682844-mRM.png)

Caso positivo, basta clicar em **Esconder Integrador.**

Caso haja algum indicador em vermelho, **clicar em Validar Configurações e conferir se vai aparecer alguma mensagem de erro específica.**