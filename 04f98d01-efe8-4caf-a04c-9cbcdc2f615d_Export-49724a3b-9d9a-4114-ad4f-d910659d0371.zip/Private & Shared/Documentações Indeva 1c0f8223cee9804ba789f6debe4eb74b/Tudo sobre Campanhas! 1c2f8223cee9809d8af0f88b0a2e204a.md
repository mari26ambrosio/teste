# Tudo sobre Campanhas!

Para incentivar e melhorar a performance de algum **indicador de venda** da loja (**Percentual da 1ª meta, Volume de vendas, quantidade de peças, Peças por atendimento, Ticket médio ou Taxa de conversão**), as campanhas são perfeitas para estimular uma competição saudável entre os vendedores (da loja).

Para criar uma campanha é simples! É só ir no menu “🏆Ranking” (lateral esquerda) clicar em **“+ Adicionar”** no campo **“Campanhas de loja”**.