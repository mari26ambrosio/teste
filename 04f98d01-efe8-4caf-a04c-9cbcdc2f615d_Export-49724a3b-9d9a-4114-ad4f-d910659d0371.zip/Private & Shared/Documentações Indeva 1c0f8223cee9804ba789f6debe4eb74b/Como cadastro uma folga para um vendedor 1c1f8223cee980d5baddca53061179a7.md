# Como cadastro uma folga para um vendedor?

O ciclo de uma meta considera os dias úteis de um período para calcular a meta dos vendedores. Por isso, você precisa especificar quais dias dentro daquele ciclo não são úteis, como é o caso dos feriados ou folgas.

Para fazer o cadastro de folgas e feriados, é só seguir este passo a passo: **👉 [Folgas e feriados](PASSO%206%20-%20Folgas%20e%20feriados%201c1f8223cee980a1b477fd3fb81ac769.md)**