# Alterar acesso de Supervisor/Administrador/Franqueado

Na Indeva, **usuários** são todos aqueles que utilizam a plataforma mas não são gerentes nem vendedores. É o caso dos **franqueados, supervisores, consultores, entre outros equivalentes.**

[**Consulte aqui**](Cadastrar%20um%20novo%20usua%CC%81rio%20(franqueado,%20supervisor%201c0f8223cee98088b341cea602a331e4.md) as informações necessárias para alterar as lojas no acesso de um usuário.

> ⚠️Importante: o pedido de alteração deve ser feito por um usuário com acesso superior.
> 
> 
> Exemplo: para criar um acesso de supervisor, é necessário autorização do franqueado ou do administrador da conta.
> 

OBS: Se você deseja que um(a) gerente tenha acesso a mais de uma loja, a situação é um pouco diferente. Nesse caso, você precisará cadastrá-lo(a) como **gerente temporário(a)**  na outra loja.