# Filtrar dados

Os filtros tem o poder de desenhar recortes dos cenários da lojas. É possível encontrar eles nos seguintes pontos da plataforma:

É possível visualizar informações importantes da performance da loja e dos vendedores! Mas antes de consultar essa riqueza de dados é preciso **filtrar o período que deseja visualizar**.

Além da data, em determinados ambientes também pode **filtrar os dados por loja ou por vendedor**.

👉 **Para personalizar a exibição dos dados** utilize sempre o botão **FILTRAR**, em cada página o botão vai apresentar as informações que são possíveis de realizar o filtro.

Abaixo, a especificidade de cada p´´agina:

> ⚠️ **Atenção - Cada ambiente já passar por um pré filtro e é preciso conferir antes de conferir as informações de qualquer relatório. =)**
> 

### **Relatórios**

Em “**Relatórios**” é possível visualizar informações de período de data; Agrupar por: Rede, Loja e Vendedor; escolher entre as redes e Lojas, como também, se disponível por Subgrupos;

![](https://cdn.elev.io/file/uploads/tBgen6l2bR68tnG4jliwz2r3Y7l43THZ1FPLchAS11w/8oOV_AvVdNKFsKI-j9NMvNXzpQXi0SlGNnQ-B0unreI/1666012977577-B0k.png)

### **Rankings**

Em “**Rankings**” é possível visualizar informações das campanhas e Rankings a partir da data de finalização.

### **Validação**

Em “**Validação**” é possível visualizar informações através do Ciclo da meta e, caso no seu acesso tenha mais de uma loja, filtrar a loja.

### **Feedbacks (Gerentes/Vendedores)**

**Feedback de Gerente**: É possível filtrar por Rede e Lojas.

**Feedbacks de Vendedores:** É possível filtrar por Rede, Lojas e, caso tenha, subgrupos.

### **Cadastros**

**Cadastro de metas:** É possível filtrar por Rede, Lojas e, caso tenha, subgrupos.

**Cadastro de Vendedores:** É possível filtrar por status, Rede, Lojas e, caso tenha, subgrupos.

**Cadastro de Gerente:** É possível filtrar por status, Rede, Lojas e, caso tenha, subgrupos.