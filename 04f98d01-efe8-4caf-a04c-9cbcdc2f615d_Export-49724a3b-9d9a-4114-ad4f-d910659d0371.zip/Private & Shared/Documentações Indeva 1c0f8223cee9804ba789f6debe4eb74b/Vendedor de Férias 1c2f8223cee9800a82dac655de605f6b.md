# Vendedor de Férias

Para colocar um vendedor de férias na Indeva é simples!

> Entre no Menu (na lateral esquerda) > Cadastro > Vendedores ”.
> 

Clique em "**ações**", "**Férias** ou inativar". Conforme abaixo:

![](https://cdn.elev.io/file/uploads/QBzHaXAsXxOVU9cJt8qy4K7_fCUmprAgEkSOPIaQEPs/CwwM1wnv-rIrotcLhq-pPCktB8xZqs4NkmhkPzqseEM/Snap%202018-01-19%20at%2011.03.08-kQ0.png)

Clique em **"Ausência temporária"**, selecione o **"motivo da ausência"** que neste caso é **"Férias"** e "**a data de saída e retorno das férias**". Conforme abaixo:

![](https://cdn.elev.io/file/uploads/QBzHaXAsXxOVU9cJt8qy4K7_fCUmprAgEkSOPIaQEPs/N8c_3OlADCZAPqOOCqqb26lkKIE2p4PM8ruun8QweT0/Snap%202018-01-19%20at%2015.06.41-6Hw.png)

**😉 DICA -** Fique atento na hora de preencher a data de saída e retorno das férias do vendedor, não é possível editá-la depois!