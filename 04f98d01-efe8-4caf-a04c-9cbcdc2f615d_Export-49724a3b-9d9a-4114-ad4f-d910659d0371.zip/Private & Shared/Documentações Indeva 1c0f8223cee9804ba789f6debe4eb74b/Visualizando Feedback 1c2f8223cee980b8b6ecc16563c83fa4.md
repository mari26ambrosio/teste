# Visualizando Feedback

Acompanhe o feedback do seu gestor na plataforma Indeva!

O gerente acessa o seu feedback em **Feedback > Gerente > Visualizar.** Aqui, você pode conferir os indicadores e também visualizar o feedback recebido. Você também pode fazer comentários no feedback para alinhar um plano de ação com o seu gestor.

Então **fique atento** nesse recurso para não deixar passar nenhum comentário.

![](https://cdn.elev.io/file/uploads/QBzHaXAsXxOVU9cJt8qy4K7_fCUmprAgEkSOPIaQEPs/s2sWMNkbqwXsmcZw4cobEKsas1TrBXP20fibPdu5GFQ/Snap%202018-11-23%20at%2016.35.57-8e0.png)

**Dica:** Aproveite esse recurso para alinhar as estratégias da loja com seu gestor e *alavancar as vendas*! 🚀 💰