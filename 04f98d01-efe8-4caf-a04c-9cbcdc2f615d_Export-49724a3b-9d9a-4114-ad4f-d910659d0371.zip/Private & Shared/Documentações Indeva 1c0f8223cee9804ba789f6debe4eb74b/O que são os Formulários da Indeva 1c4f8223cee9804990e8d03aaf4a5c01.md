# O que são os Formulários da Indeva?

Saiba como utilizar esse recurso na plataforma Indeva:

**O Formulário** é um recurso desenvolvido para atender a necessidade de **consultores de redes e supervisão de loja** sobre o acompanhamento de demandas e rotinas em loja com os gerentes ou VR. Com os **Formulários, perguntas-chave são enviadas para as lojas** para coletar quais são os planos de ação de cada loja, podendo abordar assuntos, como o desempenho da loja com a Indeva e, ao mesmo tempo, trazendo clareza do planejamento para o franqueado, abordando assuntos sobre a gestão do ponto de venda, podendo conferir organização de loja, vitrine, campanhas de promoções, treinamento dos vendedores, etc.

Em algumas redes esse acompanhamento é chamado de **"Checklist"**, mas a definição é a mesma.

**Quem está habilitado para adicionar o formulário?🤔**

Os usuários **Supervisor e Consultor** estão habilitados para adicionar novo formulário na plataforma Indeva.

**Quem pode responder um formulário criado?**🤔

O objetivo do formulário é relacionar o supervisor/consultor com o gerente ou VR de loja, então o ideal é que o formulário seja respondido por eles, mas os demais usuários podem comentar alguma resposta para indicar uma orientação.

**Dica** ✨ - Aproveite esse recurso para registrar os planos de ação com as lojas e acompanhar as rotinas dos seus gerentes! Lembre-se que acompanhamento e sucesso andam juntos!!😊