# Alterar Marcações na Lista da vez

As marcações são tudo que o vendedor pode selecionar na Lista da vez para informar como foi o atendimento dele. Exemplo: Troca, Múltiplos atendimentos, Sucesso, Reserva de outro vendedor e etc.

> 👉 **Todas as alterações nas marcações são feitas por rede**
> 

Diferente dos motivos de não conversão, as marcações na Lista da vez não são ajustadas por planilha e sim de forma manual pelos Analistas do Suporte Indeva.