# Erro "Request was denied for security"

Na última sexta-feira, dia 10 de Novembro de 2023, observamos um cenário não mapeado pelo time de suporte.

Dispositivos com versão Android igual ou inferior à versão 4.4.4 (2013), não prosseguiam na validação do token e/ou o seguinte erro retornava ao acessar a Lista da Vez: *"Request was denied for security".*

Embora **nenhuma atualização foi feita nesta versão do App,** identificamos que uma possível atualização de segurança no firewall estava fazendo um bloqueio na abertura/usabilidade de diversos apps, incluindo a Indeva - Lista da Vez.

Isso porque o sistema operacional Android 4.x foi descontinuado e consequentemente outras ferramentas e sistemas também não são mais compatíveis com o mesmo. Conforme [**divulgado aqui**](https://help.heroku.com/LBVEYASY/acm-certificate-compatibility-faq), Este foi o caso do certificado de segurança Let's Encrypt, que é o responsável por assegurar o acesso ao App.

Pensando nas possíveis alternativas para contornarmos este cenário, fizemos uma alteração recente no provedor dos nossos certificados de segurança na versão do App instalada neste sistema operacional, para possibilitar o acesso ao mesmo e o uso de suas funcionalidades.

> Para atualizar o certificado de segurança e retomar o acesso, é necessário fechar o aplicativo e abrir novamente. Caso ainda assim o problema persista, entre em contato com nosso suporte para que possamos auxiliá-lo da melhor forma.
> 

É importante ressaltar que, com a constante evolução dos sistemas operacionais e demais ferramentas relacionadas, para continuar utilizando todas as funcionalidades do nosso aplicativo da melhor forma possível e garantir sua segurança, recomendamos que você considere as seguintes opções:

**1. Atualização do Dispositivo**

Recomendamos que você considere a possibilidade de atualizar o sistema operacional do seu dispositivo para uma versão mais recente do Android, se for compatível. Isso não só garantirá a compatibilidade com nosso aplicativo, mas também oferecerá uma experiência mais segura e atualizada.

**2. Migração para o Sales App - Lista da Vez**

O VTEX Sales App é a principal solução da VTEX para operações de Comércio Unificado e pode ser instalado em dispositivos superiores ao Android 10. Ele é um aplicativo que permite integrar seus canais de venda online e físicos, colocando seus clientes no centro do negócio. Com ele, você possui a funcionalidade Lista da Vez, de forma mais completa, segura e atualizada.

3. **Acesso o VTEX Sales App via Navegador**

Se a atualização do sistema operacional não for uma opção viável, você ainda poderá acessar nossos serviços por meio de um navegador da web em seu dispositivo. Embora a experiência possa ser um pouco diferente, você continuará tendo acesso às funcionalidades principais.

> Entendemos que mudanças como essa podem ser inconvenientes, mas estamos comprometidos em fornecer a melhor experiência possível aos nossos usuários.
> 

Agradecemos sua compreensão e colaboração enquanto trabalhamos juntos para garantir uma transição tranquila.