# Vendedor responsável (VR)

O **Vendedor Responsável (VR)** tem as seguintes permissões:

- Acesso ao ambiente web Indeva
- Participa da Meta da loja
- Participa da organização da lista da vez através do App Indeva - Lista da Vez

> Você precisa primeiro ter o vendedor cadastrado na loja ([clique aqui para saber como cadastrar um vendedor](Cadastro%20de%20vendedor%201c0f8223cee9804f821dc1fff55b500a.md)). Só assim será possível dar a ele a permissão de VR.
> 

No painel do vendedor, em **Ações** você precisa clicar em Tornar V.R.

![](https://cdn.elev.io/file/uploads/vvJa8Eygp4CZPDf4NGbPAIydeLJytLeTCol2pMkU-no/BLpABAZaOIY2UY8Y0mSfSSDBUgM63FLjesQ9PKYGFkM/1652474044537-0As.png)

Em seguida será preciso informar as seguintes informações:

- **E-mail** (para que tenha acesso ao ambiente web)
- **Data de início como VR** (Informar a data que ele vai conseguir acessar as informações)
- **Comentário** (opcional)

Após preencher todas essas informações, é só clicar em **Tornar vendedor responsável** e pronto! ✨

![](https://cdn.elev.io/file/uploads/vvJa8Eygp4CZPDf4NGbPAIydeLJytLeTCol2pMkU-no/Dfdn0WRUCK29S2rI-ddKjOrogc3z3lodguB6l3xmIvk/1652474235769-FlA.png)

> Importante: A senha de acesso do ambiente web será feito no primeiro login da plataforma.
>