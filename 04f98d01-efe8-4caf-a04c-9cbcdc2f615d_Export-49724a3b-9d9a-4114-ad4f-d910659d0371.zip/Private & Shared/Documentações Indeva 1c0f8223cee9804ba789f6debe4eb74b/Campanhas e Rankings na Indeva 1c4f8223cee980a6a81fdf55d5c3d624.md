# Campanhas e Rankings na Indeva

🎥Nesse **Webinar** apresentamos dois grandes aliados que você pode explorar na **Indeva** para aumentar o engajamento da sua equipe e melhorar os seus resultados!! Vamos falar sobre Campanhas e Rankings!

Assista o vídeo e confira as informações necessárias para cadastrar os dados e motivar seu time aí na loja! 😉

Assista por esse link: [**https://youtu.be/troM-zUwIec**](https://youtu.be/troM-zUwIec)