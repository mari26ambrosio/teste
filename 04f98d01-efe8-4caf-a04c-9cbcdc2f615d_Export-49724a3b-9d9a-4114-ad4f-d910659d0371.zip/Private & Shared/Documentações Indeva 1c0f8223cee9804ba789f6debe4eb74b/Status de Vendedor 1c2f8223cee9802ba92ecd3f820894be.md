# Status de Vendedor

Na tela de “**cadastros de vendedores**” é possível **filtrar os vendedores pelo status** (Ativos, férias/licença e desligados) clicando no botão **Filtros,** no canto superior direito da tela. Aliás, vale recapitular os diferentes status e seus significados:

- **Ativos**  quando existe um período ativo sendo vendedor permanente ou temporário.
- **Férias/Licença -** quando existe um período ativo, porém em licença temporária.**Exemplo:** licença maternidade, licença médica ou Férias.
- **Desligados -** não existe período ativo.