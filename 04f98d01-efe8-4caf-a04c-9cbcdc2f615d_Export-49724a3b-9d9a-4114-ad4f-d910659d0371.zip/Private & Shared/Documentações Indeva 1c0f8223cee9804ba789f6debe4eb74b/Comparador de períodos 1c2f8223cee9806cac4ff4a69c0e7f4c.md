# Comparador de períodos

Nesta tela você consegue comparar períodos atuais com períodos anteriores e selecionar a data que quiser!

Você acessa o **Comparador de períodos** assim:

> Entre no Menu da Indeva (na lateral esquerda) > 📄 Relatórios > Comparador de Períodos.
> 

Neste relatório você vai conseguir ter uma visão estratégica das suas vendas e indicadores. Através das cores a plataforma Indeva mostra se o resultado ficou acima ou abaixo da comparação dos períodos.

Para filtrar a data desejada, clique em **Filtros**, no canto superior direito da tela.