# Por que as vendas de um vendedor não aparecem?

Esse artigo tem a intenção de apoiar nas seguintes dúvidas:

> - As vendas de apenas um vendedor não aparecem?
- Ou as vendas estão sendo atualizadas, mas não estão sendo direcionadas para seus vendedores?
> 

Esse cenário pode ocorrer pois quando o vendedor foi cadastrado, não foi informado o **Código do PDV**.

> 💡 O Código de PDV é o número sequencial que seu PDV (sistema de vendas/Ponto de Venda) utiliza para identificação do seu vendedor. Ele pode ser*:
> 
> 
> *1 - CPF do vendedor2 - Um número sequencial (definido pelo seu PDV)*
> *Caso não tenha certeza de onde encontrar ou qual modelo seu sistema utiliza, consulte as informações do seu sistema de Vendas
> 

Para adicionar o Código do PDV em seu vendedor na Indeva, você precisa ir em **Cadastro > Vendedores.**

Nesta tela, vai aparecer a relação de todos os vendedores e você poderá observar o vendedor que está sem informação e ir em **Ações > Editar Período na loja.**

Abaixo um vídeo que demonstra como fazer:

![](https://cdn.elev.io/file/uploads/tBgen6l2bR68tnG4jliwz2r3Y7l43THZ1FPLchAS11w/iWRP3ZwGex6pWNX7rTblp2031O7YAacBcGbQRSHDsQc/C%C3%B3digo%20do%20Vendedor-CPg.gif)

> ⚠️ Importante: Enquanto seu vendedor não estiver informado corretamente qual código ele representa, as informações de vendas aqui na Indeva estarão agrupadas como "Outras Vendas".
> 
> 
> Para ajustar, é preciso ir em Validação e validar ou refazer a validação dos dias anteriores, [**saiba como aqui**](Validac%CC%A7a%CC%83o%20manual%201c0f8223cee9805aa4adee5d05ba5945.md).
>