# PASSO 5 - Valores dos períodos da meta

Nesta etapa, você define qual será o valor da meta. A forma de configurar os valores depende da sua opção por estabelecer **Metas por mês** ou **Metas por período** no [**PASSO 2 - Controle do ciclo de meta**.](PASSO%202%20-%20Controle%20do%20ciclo%20de%20meta%201c1f8223cee9805891c8e432c572e6d0.md) Veja mais detalhes a seguir.

🧐 Fique ligado: você pode cadastrar, no máximo, cinco metas por período. Em casos em que o ciclo da meta consiste em apenas um período, a primeira meta configurada será o valor total da meta daquele ciclo.

---

## **Meta por mês**

Caso você tenha optado pela **meta por mês** no [**PASSO 2 - Controle do ciclo de meta**](PASSO%202%20-%20Controle%20do%20ciclo%20de%20meta%201c1f8223cee9805891c8e432c572e6d0.md), você deve cadastrar o valor mínimo total da meta e seus desdobramentos.

No contexto do varejo, alcançar o valor mínimo não é o bastante. Consequentemente, adicionar mais de uma meta é um incentivo para os vendedores performarem mais e aumentarem a margem de lucro, tanto para o vendedor quanto para a loja.

Confira os passos para cadastrar as metas:

1. No campo **R$**, escreva um valor para a 1ª meta.
2. Caso queira adicionar mais uma meta, clique em **Adicionar meta**.
3. Preencha o campo **R$** com um valor superior ao da primeira meta.
4. Clique em **Próximo**.

![](https://cdn.elev.io/file/uploads/vvJa8Eygp4CZPDf4NGbPAIydeLJytLeTCol2pMkU-no/S3WmlFmjjMZwOLaBV_aiajnkgjCmGbA3eEggdtEHRQM/image4-DIs.png)

## **Meta por período**

Se tiver optado pela **meta por período** no [**PASSO 2 - Controle do ciclo de meta**](PASSO%202%20-%20Controle%20do%20ciclo%20de%20meta%201c1f8223cee9805891c8e432c572e6d0.md), você pode definir metas distintas para cada período. Isso significa que cada meta por período é independente entre si e a meta do ciclo é a soma dos períodos.

Por exemplo: digamos que um ciclo seja dividido em dois períodos, ilustrados a seguir. No primeiro, consta uma meta inicial de R$120.000. Já o segundo período tem uma meta inicial de R$140.000. O valor total dessa meta é que a loja alcance R$260.000 em vendas até o final do ciclo.

Para cadastrar as metas do primeiro período, confira as seguintes instruções:

1. No campo em branco com o ícone **R$**, escreva um valor para a meta.
2. Caso queira adicionar mais metas, clique em **Adicionar meta**.
3. Preencha o campo em branco com o ícone **R$** com um valor superior ao da primeira meta.
4. Clique em **Próximo**.

![](https://cdn.elev.io/file/uploads/vvJa8Eygp4CZPDf4NGbPAIydeLJytLeTCol2pMkU-no/GfP_UNmISweZeEfJjRq0TzmmRGX070RP-GMBMWM3Nrs/image1-h0Y.png)

Para cadastrar metas nos períodos seguintes, clique em **Cadastrar 2º período** e repita os passos descritos anteriormente. Caso você prefira deixar para depois, sem problemas!

**Você não precisa cadastrar de uma só vez todas as metas de todos os períodos.** O período obrigatório é aquele que está imediatamente por vir — isso permite que você crie metas fiéis e adaptáveis ao desempenho de seus vendedores a cada período! 😉

Por exemplo: quando você está criando uma meta pela primeira vez, você apenas precisa criar e distribuir a meta para o 1º período. Nesse momento, criar metas para os demais períodos é opcional. Quando o 1º período acabar, passa a ser obrigatório criar e distribuir as metas para o 2º período e assim sucessivamente, até os períodos cadastrados terminarem.

### **Como criar metas para o próximo período quando o período atual terminar?**

Como o cadastro de **metas por período** permite que você crie e distribua metas a cada período, quando um período chega ao fim, é importante que você cadastre a meta do período que está para começar, caso ainda não tenha cadastrado.

Para isso, acesse a meta que está em andamento conforme as instruções a seguir.

1. Clique em **Cadastros** > **Metas**.

2. Na listagem de metas, passe o cursor sobre o botão **Ações** e clique na opção **Editar**.

3. Na página de resumo da meta, ilustrada abaixo, você verá um alerta informando que está na hora de criar as metas do período que vai começar. Clique no botão ou no link **Editar meta da loja**.

![](https://cdn.elev.io/file/uploads/vvJa8Eygp4CZPDf4NGbPAIydeLJytLeTCol2pMkU-no/LeUTti3WK_MOSVs9LueJdPpsPzbalwXyjv23QHAGF6I/editar-meta-dXg.png)

Você será conduzido(a) para a etapa ilustrada a seguir para prosseguir com o cadastro.

![](https://cdn.elev.io/file/uploads/vvJa8Eygp4CZPDf4NGbPAIydeLJytLeTCol2pMkU-no/iTQjcieVsDzShn0Nr8arq_lK7Bc-wOifD7_6qIJNzxA/image2-vN4.png)