# Visualizar feedback no app Indeva - Lista da vez

O Vendedor tem a possibilidade de conferir no app Indeva - Lista da Vez os feedbacks registrados para ele.

Será possível conferir os registros de Elogios e Orientações feitas a partir dos resultados.

Para conferir no app Indeva - Lista da Vez o Feedback do Vendedor, com o app aberto, clique na aba Metas. Em seguida escolha o nome do vendedor > Digite a senha e pronto.

![](https://cdn.elev.io/file/uploads/tBgen6l2bR68tnG4jliwz2r3Y7l43THZ1FPLchAS11w/45M7HK5sefTCj2K1vgl24kL-svD3nIqTNk35i3FPEA8/1661783434514-k_U.gif)

> Importante destacar que o feedback fica disponível no período seguinte.
> 
> 
> É possível conferir através da data que fica logo abaixo do comentário sobre o feedback.
> 

![](https://cdn.elev.io/file/uploads/tBgen6l2bR68tnG4jliwz2r3Y7l43THZ1FPLchAS11w/4jYTtMUpd37_gw4cdX3ypwu9N0umw3YRiw9lxgN8t48/1661783830618-xmo.png)