# Como desligo um colaborador?

O caminho para desligar o colaborador depende se ele é vendedor ou gerente.

**1) Para desligar um vendedor:**

Entre em Cadastros > Vendedores > Ações > Férias ou Inativar > **Desligamento**.

**2) Para desligar um gerente*:**

Entre em Cadastros > Gerentes > Ações > Férias ou Inativar > **Desligamento**.

> *⚠️Importante: somente usuários com acesso superior ao de gerente (supervisores, consultores, administradores ou franqueados) podem desligar um gerente.
> 

---

## **O que fazer quando a opção de desligar está indisponível?**

Nesse cenário existem as seguintes hipóteses:

***1 - O colaborador é um Vendedor responsável:***

Para inativar um V.R. é preciso consultar os passos [**deste artigo**](https://indeva.elevio.help/pt-br/articles/112)

***2 - O colaborador está com um período de inativação cadastrada:***

O colaborador já pode estar com um período de desligamento vinculado, pode ser uma inativação do tipo fixo ou temporário e por essa razão o botão não aparece no perfil do colaborador.

Nesse caso você precisa ajustar essa ausência temporária para então poder fazer a inativação:

- Vá até o Cadastro de Vendedores e **filtre pelos cadastros de licenças/férias** (botão FILTROS no topo da página)**;**

![](https://cdn.elev.io/file/uploads/tBgen6l2bR68tnG4jliwz2r3Y7l43THZ1FPLchAS11w/52EJsyaRBrpcD4yPaVr-rLsokBoXWlx75LvTf7d5hFc/1677181738577-5CI.gif)

- Abra o cadastro do vendedor em questão, indo em **Ações >** ***Editar Período na loja***, e altere a data final dessa ausência e salve.

O vendedor ficará ativo e você vai poder então inativar o cadastro.

> ⚠️Importante: O painel de cadastro de Vendedor ou gerente é sobre os períodos, ou seja, o colaborador pode aparecer mais de 1 vez - pois o que é apresentado são os períodos dele.
>